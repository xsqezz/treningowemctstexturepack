#version 330
#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 10
#define SHADER_VERSION 2
#moj_import <fog.glsl>
#if SHADER_VERSION >= 2
#moj_import <dynamictransforms.glsl>
#moj_import <globals.glsl>
in float sphericalVertexDistance;in float cylindricalVertexDistance;
#else
uniform vec4 ColorModulator;uniform float FogStart;uniform float FogEnd;uniform vec4 FogColor;in float vertexDistance;
#endif
uniform sampler2D Sampler0;in vec4 vertexColor;in vec2 texCoord0;out vec4 fragColor;
#if SHADER_VERSION >= 2 && !defined(IS_GUI) && !defined(IS_SEE_THROUGH) && !defined(IS_GRAYSCALE)
#define MCTS_TEXT_PIPELINE
#moj_import <minecraft:mcts_text_stage_fragment.glsl>
#endif
void main() {
#ifdef MCTS_TEXT_PIPELINE
gl_FragDepth = gl_FragCoord.z;if (mctsClaimed == 0) {mcts_text_fragment();return;}
#endif
#ifdef IS_GRAYSCALE
vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
vec4 texColor = texture(Sampler0, texCoord0);
#endif
#ifdef IS_SEE_THROUGH
vec4 color = texColor * vertexColor;
#else
vec4 color = texColor * vertexColor * ColorModulator;
#endif
#ifdef MCTS_TEXT_PIPELINE
if (int(fshEffectID + 0.5) == 11) {color.rgb = mix(color.rgb, fshEffectColor.rgb, shineMask(fshEffectParams, GameTime) * SHINE_STRENGTH);}
#endif
if (color.a < 0.1) {discard;}
#ifdef IS_SEE_THROUGH
fragColor = color * ColorModulator;
#elif defined(IS_GUI)
fragColor = color;
#elif SHADER_VERSION >= 2
fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#else
fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
#endif
}