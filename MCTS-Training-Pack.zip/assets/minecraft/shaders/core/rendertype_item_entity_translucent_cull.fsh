#version 330

// ================================================================
//  MCTS world border + stage lights - fragment stage
// ================================================================

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:mcts_border_types.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;

in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;
in vec2 texCoord2;
in vec4 normal;

in vec4 ray_pos1, ray_pos2, ray_pos3, ray_pos4;
in vec3 ray_uv1, ray_uv2;
in vec3 ray_glPos;
in vec4 ray_lightMapColor;

#define MAX_DEPTH 1000000

flat in int type;
flat in ivec2 mctsLightInfo;

out vec4 fragColor;

#moj_import <minecraft:mcts_border_raymarch.glsl>
#moj_import <minecraft:mcts_stage_light.glsl>

void main() {
    gl_FragDepth = gl_FragCoord.z;

    if (type == TYPE_BORDER) {
        raymarch(false);
        return;
    } else if (type == TYPE_BORDER_INNER) {
        raymarch(true);
        return;
    } else if (type == TYPE_STAGE_LIGHT) {
        stageLight();
        return;
    }

    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
