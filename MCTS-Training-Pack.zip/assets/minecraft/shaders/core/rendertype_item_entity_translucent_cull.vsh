#version 330

// ================================================================
//  MCTS world border - vertex stage
// ----------------------------------------------------------------
//  Ordinary items keep the vanilla path. A quad whose texture carries
//  the border marker texel is turned into a full-screen ray, and the
//  fragment stage raymarches the border cylinder through it.
//
//  In 1.21.5+ every item that Minecraft draws with a translucent
//  sheet - dropped, held, in an item_display - goes through this
//  render type, so this single core shader covers them all.
//
//  Ten sam mechanizm niesie reflektory sceniczne (mcts_stage_light.glsl):
//  inny texel-znacznik, a brightness displaya (UV2) idzie do fragmentu
//  jako faza ruchu i preset koloru.
// ================================================================

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:mcts_border_types.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;
out vec4 normal;

out vec4 ray_pos1, ray_pos2, ray_pos3, ray_pos4;
out vec3 ray_glPos;
out vec3 ray_uv1, ray_uv2;
out vec4 ray_lightMapColor;

flat out int type;
flat out ivec2 mctsLightInfo;

float getFOV(mat4 ProjMat) {
    return atan(1.0, ProjMat[1][1]) * 114.591559;
}

ivec4 nearest(vec4 a) {
    return ivec4(a * 255.0 + 0.5);
}

void main() {
    type = TYPE_VANILLA;
    mctsLightInfo = ivec2(0);
    normal = vertexColor = ray_lightMapColor = ray_pos1 = ray_pos2 = ray_pos3 = ray_pos4 = vec4(0);
    ray_glPos = ray_uv1 = ray_uv2 = vec3(0);
    texCoord0 = texCoord1 = texCoord2 = vec2(0);

    ivec4 t = nearest(texture(Sampler0, UV0));
    bool outer = t == ivec4(117, 195, 186, 241);
    bool stageLight = t == ivec4(200, 120, 40, 245);
    if (outer || t == ivec4(117, 195, 186, 243) || stageLight) {
        type = stageLight ? TYPE_STAGE_LIGHT : outer ? TYPE_BORDER : TYPE_BORDER_INNER;
        mctsLightInfo = UV2 / 16;
        const vec2[4] corners = vec2[4](vec2(0), vec2(0, 1), vec2(1, 1), vec2(1, 0));
        vec2 corner = corners[(gl_VertexID+2) % 4].yx;

        vec2 texSize = textureSize(Sampler0, 0);
        vec2 uv = floor(UV0 * texSize);

        vec4 modelPos = ModelViewMat * vec4(Position, 1.0);
        modelPos.xy += ProjMat[3].xy / vec2(ProjMat[0][0], ProjMat[1][1]);

        vec2 cornerT = corner * 2 - 1;
        if (ProjMat[3][0] == -1)
            cornerT = cornerT.yx * 32;

        float fov = getFOV(ProjMat);

        switch (gl_VertexID % 4) {
            case 0:
                cornerT.x *= 3;
                break;
            case 2:
                cornerT.y *= 3;
                break;
            case 3:
                cornerT.xy *= 0;
                break;
        }

        // aspect ratio
        cornerT.x *= ProjMat[1][1] / ProjMat[0][0];
        vec4 glPos = vec4(0,0,0,1) + vec4(cornerT * tan(fov * 0.5 * 0.0174532925) * 1.08, 0, 0);

        modelPos.w = 1;

        switch (gl_VertexID % 4) {
            case 0:
                ray_pos1 = modelPos;
                ray_uv1 = vec3(uv, 1);
                break;
            case 1:
                ray_pos2 = modelPos;
                break;
            case 2:
                ray_pos3 = modelPos;
                ray_uv2 = vec3(uv, 1);
                break;
            case 3:
                ray_pos4 = modelPos;
                break;
        }

        glPos.z = min(glPos.z, -1);
        ray_glPos = glPos.xyz;
        mat4 proj = ProjMat;
        proj[3].xy = vec2(0, 0);
        gl_Position = proj * glPos;

        vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, vec4(1.0));
        ray_lightMapColor = texelFetch(Sampler2, UV2 / 16, 0);
        return;
    }

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;
    normal = ProjMat * ModelViewMat * vec4(Normal, 0.0);
}
