// ================================================================
//  Loading screen effect - CONFIG
//  All tweakable values for loading_screen.glsl live here.
// ================================================================
//
//  ZNACZKI / KOMENDY (20t = 1 sekunda):
//
//  Te same znaczki robia IN i OUT - o kierunku decyduje KOLOR tytulu
//  (biale #FFFFFF = in, "prawie biale" #FFFFFE = out; kazdy kolor z
//  niebieskim < 254 tez wlacza out, ale #FFFFFE wyglada identycznie
//  jak bialy). Osobne znaczki "out" nie istnieja.
//
//  JAK DZIALA CZAS:
//    fade-in  = animacja WEJSCIA - gwiazdka zamyka sie przez CALY
//               fade-in (logo w pelni widoczne na koncu)
//    stay     = jak dlugo ekran ZOSTAJE po wejsciu
//    fade-out = wyjscie - gwiazdka otwiera sie przez CALY fade-out,
//               zaczynajac od razu
//    gwiazdki w tle, shimmer na logo i pasek ladowania chodza na
//    GameTime, czyli plynnie CALY czas (takze podczas stay) i nigdy
//    sie nie resetuja przy zmianach title.
//
//  PASEK LADOWANIA:
//    Tor paska pojawia sie na samym koncu fade-inu (LS_BAR_APPEAR),
//    czyli w momencie startu stay, i jedzie przez caly stay. Faza
//    przesuwu idzie wprost z globalnego zegara gry (GameTime), wiec
//    pasek moze pojawic sie w polowie przesuwu - to celowe, zadnego
//    wyrownywania nie trzeba robic. (Ciekawostka: jesli wyslesz IN w
//    ticku podzielnym przez 50 i z fade-in podzielnym przez 50t, to
//    pierwszy przesuw akurat ruszy od lewej - ale to opcjonalne.)
//
//  IN (wejscie 5s = 100t, zostaje 60s - zamknij wczesniej OUT):
//      /title @s times 100t 1200t 0t
//      /title @s title "载甲乙丙丁"
//
//  OUT - bez paska ladowania, gwiazda otwiera sie OD RAZU i rosnie
//  przez caly fade-out (5s = 100t; daj mniej, np. 20t, zeby wyjscie
//  bylo szybsze):
//      /title @s times 0t 0t 100t
//      /title @s title {"text":"载甲乙丙丁","color":"#FFFFFE"}
//
//  OUT mozna wyslac w kazdej chwili (nawet w trakcie IN) - animacja
//  od razu przechodzi w wyjscie, a tlo/shimmer plynnie leca dalej.
// ================================================================

// --- backdrop ---------------------------------------------------
#define LS_BACKGROUND     (vec3(23, 23, 29) / 255)
#define LS_BG_TINT        1.45               // background star brightness vs backdrop
#define LS_BG_CELL        0.24               // scatter cell size, in screen heights
#define LS_BG_MAX_FT      3                  // max fifth-turns (72 deg) per star per
                                             // LS_TIME_SCALE seconds (1 = slowest)
#define LS_BG_SHAPE       3.0                // 2 = pentagon-ish ... 5 = spiky
#define LS_BG_ROUND       0.45               // corner rounding, fraction of radius
                                             // (0.45 = strongly rounded points)
#define LS_BG_SEED        137.0              // randomness seed for the star field
                                             // (change for a different scatter/spin mix)

// --- loading bar -------------------------------------------------
#define LS_BAR_TRACK      (vec3(14, 14, 19) / 255)
#define LS_BAR_LEFT       (vec3(255, 205,  66) / 255)  // gold
#define LS_BAR_RIGHT      (vec3(238, 128,  24) / 255)  // orange
#define LS_BAR_SIZE       vec2(0.22, 0.016)  // bar half-size, in screen heights
#define LS_BAR_PERIOD     2.5                // seconds per loading-bar sweep
#define LS_BAR_SEGMENT    0.38               // moving segment width, fraction of track
#define LS_BAR_POS        vec2(0.0, -0.24)   // bar center offset from screen center

// --- star iris ---------------------------------------------------
#define LS_STAR_POINTS    5.0                // 5-pointed star, point up
#define LS_STAR_SHAPE     3.0                // 2 = polygon-ish ... LS_STAR_POINTS = spiky
#define LS_STAR_ROUND     0.25               // corner rounding, fraction of radius

// --- logo --------------------------------------------------------
#define LS_LOGO_HEIGHT    0.20               // logo height, in screen heights
#define LS_LOGO_POS       vec2(0.0, 0.09)    // logo center offset from screen center
#define LS_SHIMMER_PERIOD 2.5                // seconds per shimmer sweep
#define LS_SHIMMER_OFFSET 1.25               // shimmer phase offset vs the loading bar,
                                             // in seconds (1.25 = half a period, so the
                                             // two sweeps are maximally out of sync)

// --- edges --------------------------------------------------------
#define LS_AA             0.6                // edge AA half-width, in REAL screen pixels
                                             // (0.6 -> ~1.2px transition: crisp at any resolution)

// --- timing ------------------------------------------------------
// Background stars, shimmer and the bar sweep run on GameTime (continuous,
// never resets on title changes). NOTE: GameTime wraps every 1200s;
// keep LS_BAR_PERIOD / LS_SHIMMER_PERIOD dividing 1200 evenly and
// LS_TIME_SCALE such that 1200 / LS_TIME_SCALE is whole, or the
// animation will visibly jump once every 20 minutes.
// The star iris is the only alpha-driven part: it closes over the
// WHOLE fade-in and opens over the WHOLE fade-out.
#define LS_TIME_SCALE     10.0               // seconds per 1..LS_BG_MAX_FT
                                             // fifth-turns of the background stars
#define LS_BAR_APPEAR     0.95               // the bar's track fades in over the LAST
                                             // (1 - this) of the fade-in, i.e. it shows
                                             // up right as the stay begins, then keeps
                                             // sweeping for the entire stay
