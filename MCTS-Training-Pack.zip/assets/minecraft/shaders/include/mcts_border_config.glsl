// Height of the border in blocks
#define HEIGHT 300
// Vertical displacement
#define SHIFT_Y -150
// How many blocks the border fades off from the top
#define FADEOFF 32
// How far away the border stays visible. It is a ray effect rather than geometry, so its
// range is not tied to the terrain render distance - but the far wall of an arena sits up
// to two radii away (550 blocks for SurvivalGames), and following the client's fog would
// cut it off on short render distances. Fog is only used when it falls inside this window.
#define MIN_FADE_END 640.0
#define MAX_FADE_END 1024.0
// How many blocks the border takes to fade out at that distance
#define FADE_LENGTH 64.0
// Krycie bordera. Efekty niżej dokładają koloru, ale NIE krycia - patrz clamp w
// mcts_border_raymarch.glsl. Bez niego człon "nearby squares" dorzucał do +0.375 alfy przy
// odległości <5 bloków i ściana robiła się lita dokładnie wtedy, gdy gracz do niej podchodził.
#define BORDER_ALPHA 0.6
// The number of ripples per 20 minutes (1 minecraft day), must be an integer
const int RIPPLE_SPEED = 100;

const float TILE_HEIGHT = 3; // Tile's height in blocks
const float MIN_TILE_WIDTH = 3.3; // Tile's minimum width in blocks (the maximum width is double this value)
