// ================================================================
//  MCTS stage light - konfiguracja
// ----------------------------------------------------------------
//  Reflektor sceniczny (smuga swiatla) rysowany promieniem z item
//  displaya - patrz mcts_stage_light.glsl. Dlugosc smugi i promien
//  u jej konca bierze sie ze skali displaya, faza ruchu i kolor z jego
//  brightness (block = faza 0..15, sky = preset koloru).
// ================================================================

// Znak kierunku swiecenia wzgledem normalnej quada. Renderer item displaya obraca model
// o 180 stopni wokol Y (DisplayRenderer.ItemDisplayRenderer.submitInner), wiec sciana
// "south" modelu patrzy w tyl displaya - -1 zawraca smuge na jego yaw/pitch.
#define SL_DIR_SIGN -1.0
// Promien smugi u wylotu reflektora (bloki); promien u konca to scale.y displaya
#define SL_R0 1.1
// Poczatek stozka przesuniety przed soczewke (bloki) - tyl dysku startowego nie wchodzi w korpus lampy
#define SL_FORWARD 0.7
// Liczba probek wzdluz promienia wewnatrz stozka
#define SL_STEPS 32
// Jasnosc smugi, jak szybko jej krycie sie nasyca i gorna granica krycia - smuga ma wygladac jak
// swiatlo dodane do tla, nie jak farba, wiec nigdy nie robi sie lita
#define SL_STRENGTH 2.2
#define SL_ALPHA_K 1.1
#define SL_MAX_ALPHA 0.78
// Profil poprzeczny: plaski srodek z krawedzia o szerokosci od SL_EDGE_NEAR (przy lampie) do
// SL_EDGE_FAR (na koncu) w ulamku promienia, plus jasny rdzen przy osi
#define SL_EDGE_NEAR 0.25
#define SL_EDGE_FAR 0.55
#define SL_CORE 0.9
#define SL_CORE_WIDTH 7.0
// Zanikanie wzdluz smugi (jasno przy lampie, w powietrzu gasnie; wiekszy = szybciej) i dodatkowy
// blask tuz za soczewka
#define SL_AXIAL_FALLOFF 1.6
#define SL_THROAT 0.8
// Falowanie krawedzi stozka szumem (0 = idealny stozek)
#define SL_EDGE_WOBBLE 0.06
// Pikselowy wyglad: gestosc i mgielka liczone w wokselach o tym boku (bloki) w ukladzie lampy,
// poswiata soczewki w komorkach SL_VOXEL_HALO (0 wylacza)
#define SL_VOXEL 0.5
#define SL_VOXEL_HALO 0.25
// Ruch glowicy: amplitudy w stopniach i okresy w sekundach (okres musi dzielic 1200)
#define SL_PAN_DEG 11.0
#define SL_PAN_PERIOD 16.0
#define SL_TILT_DEG 7.0
#define SL_TILT_PERIOD 10.0
// Reflektor wycelowany (faza 15, prezentacja druzyn / podsumowanie): amplitudy lekkiego kolysania,
// zeby smuga zostala na scenie, a swiatlo nie stalo jak wryte
#define SL_AIM_PAN_DEG 3.0
#define SL_AIM_TILT_DEG 2.0
// Oddychanie jasnosci
#define SL_BREATHE 0.08
#define SL_BREATHE_PERIOD 6.0
// Mgielka w smudze: skala szumu (1/bloki), rozciagniecie wzdluz osi (mniejszy = dluzsze promienie),
// predkosc przeplywu od lampy (bloki/s), kontrast promieni (0 = jednolita smuga)
#define SL_HAZE_SCALE 0.5
#define SL_HAZE_STRETCH 0.12
#define SL_HAZE_SPEED 1.4
#define SL_HAZE_AMOUNT 0.85
// Kolor: domieszka bieli do presetu (swiatlo jest pastelowe, nie nasycone) i jak szybko geste
// miejsca przepalaja sie do bieli
#define SL_PASTEL 0.08
#define SL_BURN 0.3
// Poswiata soczewki u wylotu: sila i polosie elipsy na plaszczyznie wylotu (bloki;
// dluzsza wzdluz dluzszej krawedzi quada, czyli szerokosci panelu), poziomy blysk (flare)
#define SL_HALO 1.2
#define SL_LENS_W 2.4
#define SL_LENS_H 1.1
#define SL_FLARE 0.6
// Zasieg poswiaty w jednostkach polosi (dalej jest dokladnie zero)
#define SL_LENS_REACH 2.0
// Zanikanie z odlegloscia od kamery (bloki)
#define SL_FADE_START 140.0
#define SL_FADE_END 200.0
// Slabsze fragmenty sa odrzucane (prog ciagly), wiec nie zapisuja glebokosci
#define SL_MIN_ALPHA 0.03

// Kolory presetow (sky brightness displaya 0..12); 13 = tecza, 14 = preset 0, 15 = zgaszony
const vec3 SL_COLORS[13] = vec3[13](
    vec3(1.00, 0.93, 0.80), // 0 cieply bialy
    vec3(1.00, 1.00, 1.00), // 1 bialy
    vec3(1.00, 0.72, 0.18), // 2 zloty
    vec3(1.00, 0.22, 0.18), // 3 czerwony
    vec3(1.00, 0.50, 0.10), // 4 pomaranczowy
    vec3(1.00, 0.90, 0.20), // 5 zolty
    vec3(0.20, 0.90, 0.30), // 6 zielony
    vec3(0.60, 1.00, 0.20), // 7 limonkowy
    vec3(0.30, 0.95, 1.00), // 8 turkusowy
    vec3(0.30, 0.50, 1.00), // 9 niebieski
    vec3(0.15, 0.20, 0.95), // 10 granatowy
    vec3(0.65, 0.30, 1.00), // 11 fioletowy
    vec3(1.00, 0.45, 0.80)  // 12 rozowy
);
