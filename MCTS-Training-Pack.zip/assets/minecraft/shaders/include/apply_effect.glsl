void applyEffect(inout vec4 vertex, vec4 baseColor, bool isShadow) {
    // A shadow vertex's Color is already the vanilla shadow; only an apply_color override still needs darkening.
    vec4 displayColor = (isShadow && flagColorOverride) ? vec4(baseColor.rgb * 0.25, baseColor.a) : baseColor;

    // burst: 1 w chwili wyslania tytulu, 0 po fade-in (przy fade-out odwrotnie)
    float burstT = 0.0;
    if (flagBurst) {
        burstT = 1.0 - Color.a;
        displayColor.rgb = mix(displayColor.rgb, vec3(isShadow ? 0.25 : 1.0), burstT * burstT);
        // rozszczepienie RGB wygasa z uderzeniem, potem wraca efekt fragmentowy slotu (np. shine)
        if (burstT > 0.02) {
            flagChromatic = true;
            paramChromaticIntensity = 3.0 * burstT;
            paramChromaticSpeed = 0.0;
        }
    }

    // ========================================
    // Phase 1: Blinking (short-circuit)
    // ========================================
    if (flagBlinking) {
        float blink = step(0.5, fract(GameTime * paramBlinkSpeed * 1200.0));
        if (paramBlinkSpeed > 0.0 && blink < 0.5) {
            gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
            finalize();
            return;
        }
    }

    // ========================================
    // Phase 2: Pre-projection vertex mods
    // ========================================
    if (flagShake && paramShakeSpeed > 0.0) {
        float charId = floor(float(gl_VertexID) / 4.0);
        float shakeTime = GameTime * 1200.0 * paramShakeSpeed;
        float noiseX = noise(charId * 10.0 + shakeTime) - 0.5;
        float noiseY = noise(charId * 10.0 - shakeTime + 100.0) - 0.5;
        setOffset(noiseX * paramShakeIntensity, noiseY * paramShakeIntensity);
        applyOffset(vertex);
    }

    if (flagBouncy) {
        float vertexId = mod(float(gl_VertexID), 4.0);
        float bounceTime = TAU * fract(GameTime * 1200.0 * paramBounceSpeed);
        if (paramBounceSpeed > 0.0 && (vertexId == 3.0 || vertexId == 0.0)) {
            setOffset(0.0, cos(bounceTime) * paramBounceAmplitude + max(cos(bounceTime) * paramBounceAmplitude, 0.0));
            applyOffset(vertex);
        }
    }

    if (flagPulse) {
        float pulseTime = TAU * fract(GameTime * 1200.0 * paramPulseSpeed);
        float pulseFactor = paramPulseSpeed > 0.0 ? sin(pulseTime) * 0.5 + 0.5 : 0.0;
        float expansion = paramPulseSize * 2.5 * pulseFactor;
        float vertexId = mod(float(gl_VertexID), 4.0);
        vec2 pulseDir = vec2(0.0);
        if (vertexId < 0.5) pulseDir = vec2(-1.0, -1.0);
        else if (vertexId < 1.5) pulseDir = vec2(-1.0, 1.0);
        else if (vertexId < 2.5) pulseDir = vec2(1.0, 1.0);
        else pulseDir = vec2(1.0, -1.0);
        pulseDir *= vec2(0.7, 1.0);
        vec2 pulseOffset = pulseDir * expansion;
        setOffset(pulseOffset.x, pulseOffset.y);
        applyOffset(vertex);
    }

    if (flagIterating && paramIteratingSpeed > 0.0) {
        float iterSpeed = paramIteratingSpeed;
        float iterSpace = paramIteratingSpace;
        // ponizej 0.2 mod ucina garb fali
        iterSpace = max(iterSpace, 0.2);

        // GUI: derive charId from Position so the phase stays stable when
        // batched neighbors (tab list, multi-line chat) shift gl_VertexID.
        // ~6 px per character; wide glyphs can split left/right vertices
        // across bins, but the result is far less jarring than the jump.
        float charId = (ProjMat[3][3] != 0.0)
            ? floor(Position.x / 6.0)
            : floor(float(gl_VertexID) / 4.0);
        float iterTime = TAU * GameTime * 1200.0 * iterSpeed;
        float iterX = mod(charId * 0.4 - iterTime, (5.0 * iterSpace) * TAU);
        if (iterX > TAU) iterX = TAU;
        
        setOffset(0.0, (-cos(iterX) * 0.5 + 0.5) * -2.0);
        applyOffset(vertex);
    }

    if (flagGlitch) {
        float gSpeed = paramGlitchSpeed;
        float gIntensity = paramGlitchIntensity;
        float glitchTime = floor(GameTime * 1200.0 * gSpeed);
        float glitchCharId = floor(float(gl_VertexID) / 4.0);
        float glitchTrigger = random(vec2(glitchTime * 0.1, 0.0));
        float glitchOffX = 0.0;
        float glitchOffY = 0.0;
        if (glitchTrigger > 0.7) {
            glitchOffX = (random(vec2(glitchCharId + glitchTime, 1.0)) - 0.5) * gIntensity * 4.0;
        }
        if (glitchTrigger > 0.85) {
            glitchOffY = (random(vec2(glitchCharId - glitchTime + 50.0, 2.0)) - 0.5) * gIntensity;
        }
        setOffset(glitchOffX, glitchOffY);
        applyOffset(vertex);
    }

    if (flagScale) {
        float scaleVid = mod(float(gl_VertexID), 4.0);
        vec2 scaleDir;
        if      (scaleVid < 0.5) scaleDir = vec2(-1.0, -1.0);
        else if (scaleVid < 1.5) scaleDir = vec2(-1.0,  1.0);
        else if (scaleVid < 2.5) scaleDir = vec2( 1.0,  1.0);
        else                     scaleDir = vec2( 1.0, -1.0);
        float actualExpansion = (paramScaleFactor - 1.0) * 4.0;
        scaleDir *= vec2(0.7, 1.0);
        vec2 scaleOffset = scaleDir * actualExpansion + vec2(paramScaleOffsetX, paramScaleOffsetY);
        setOffset(scaleOffset.x, scaleOffset.y);
        applyOffset(vertex);
    }

    if (flagBeat) {
        float beatVid = mod(float(gl_VertexID), 4.0);
        vec2 beatDir;
        if      (beatVid < 0.5) beatDir = vec2(-1.0, -1.0);
        else if (beatVid < 1.5) beatDir = vec2(-1.0,  1.0);
        else if (beatVid < 2.5) beatDir = vec2( 1.0,  1.0);
        else                    beatDir = vec2( 1.0, -1.0);
        // kwadrat: najwiekszy skok tuz po beacie, lagodne dojscie do rozmiaru
        float beatT = 1.0 - Color.a;
        vec2 beatOffset = beatDir * vec2(0.7, 1.0) * paramBeatPunch * beatT * beatT * 4.0;
        setOffset(beatOffset.x, beatOffset.y);
        applyOffset(vertex);
    }

    if (flagOutline) {
        float vid = mod(float(gl_VertexID), 4.0);
        vec2 outDir;
        if      (vid < 0.5) outDir = vec2(-1.0, -1.0);
        else if (vid < 1.5) outDir = vec2(-1.0,  1.0);
        else if (vid < 2.5) outDir = vec2( 1.0,  1.0);
        else                outDir = vec2( 1.0, -1.0);
        float pad = max(paramOutlineThickness, 0.5) + 1.0;
        setOffset(outDir.x * pad, outDir.y * pad);
        applyOffset(vertex);
        // Expand UV proportionally so fragments outside the original glyph map past glyph bounds.
        // MC default font atlas: 256x256, so 1 pixel = 1/256 in UV.
        texCoord0 += outDir * (pad / 256.0);
    }

    if (flagNeon) {
        // poswiata siega 3 tx poza glif - bez marginesu quad ja ucinal
        float vid = mod(float(gl_VertexID), 4.0);
        vec2 neonDir;
        if      (vid < 0.5) neonDir = vec2(-1.0, -1.0);
        else if (vid < 1.5) neonDir = vec2(-1.0,  1.0);
        else if (vid < 2.5) neonDir = vec2( 1.0,  1.0);
        else                neonDir = vec2( 1.0, -1.0);
        setOffset(neonDir.x * 4.0, neonDir.y * 4.0);
        applyOffset(vertex);
        texCoord0 += neonDir * (4.0 / 256.0);
    }

    if (flagSplit) {
        // Expand only the left vertices (vid 0 = top-left, vid 1 = bottom-left)
        // outwards so the fragment shader has rendering area to draw the
        // shifted top half at full size.  UV at these vertices is unchanged,
        // and the fragment shader rescales sampling to compensate.
        float fracVid = mod(float(gl_VertexID), 4.0);
        if (fracVid == 0.0 || fracVid == 1.0) {
            // ten sam limit co shiftRatio w split_effect.glsl, inaczej glif sie rozciaga
            setOffset(-clamp(paramSplitIntensity * 0.2, 0.05, 0.6) * 8.0, 0.0);
            applyOffset(vertex);
        }
    }

    if (flagChromatic) {
        // Expand left vertices left and right vertices right by intensity*1.5 px
        // so the fragment has room for the red/blue fringe outside the original quad.
        float vid = mod(float(gl_VertexID), 4.0);
        float dx = (vid == 0.0 || vid == 1.0) ? -1.0 : 1.0;
        float pad = paramChromaticIntensity * 1.5;
        // burst dziala na tytule (4x): margines w px GUI 4x wiekszy niz w tekselach, inaczej litery sie sciskaja
        setOffset(dx * pad * (flagBurst ? 4.0 : 1.0), 0.0);
        applyOffset(vertex);
        texCoord0.x += dx * pad / 256.0;
    }

    if (flagExtrude) {
        // Expand right/bottom vertices to cover the extruded shadow area (down-right).
        float vid = mod(float(gl_VertexID), 4.0);
        bool isRight  = (vid == 2.0 || vid == 3.0);
        bool isBottom = (vid == 1.0 || vid == 2.0);
        // fragment rysuje najwyzej 16 warstw
        float pad = paramExtrudeDepth * clamp(floor(paramExtrudeLayers + 0.5), 1.0, 16.0) + 1.0;
        setOffset(isRight ? pad : 0.0, isBottom ? pad : 0.0);
        applyOffset(vertex);
        texCoord0 += vec2(isRight ? pad / 256.0 : 0.0, isBottom ? pad / 256.0 : 0.0);
    }

    if (flagNoise) {
        // Expand all four corners outward by intensity+1 px for full displaced sampling area.
        float vid = mod(float(gl_VertexID), 4.0);
        vec2 outDir;
        if      (vid < 0.5) outDir = vec2(-1.0, -1.0);
        else if (vid < 1.5) outDir = vec2(-1.0,  1.0);
        else if (vid < 2.5) outDir = vec2( 1.0,  1.0);
        else                outDir = vec2( 1.0, -1.0);
        float pad = paramNoiseIntensity + 1.0;
        setOffset(outDir.x * pad, outDir.y * pad);
        applyOffset(vertex);
        texCoord0 += outDir * (pad / 256.0);
    }

    if (flagLiquid) {
        // Expand all four corners outward by intensity+1 px for full displaced sampling area.
        float vid = mod(float(gl_VertexID), 4.0);
        vec2 outDir;
        if      (vid < 0.5) outDir = vec2(-1.0, -1.0);
        else if (vid < 1.5) outDir = vec2(-1.0,  1.0);
        else if (vid < 2.5) outDir = vec2( 1.0,  1.0);
        else                outDir = vec2( 1.0, -1.0);
        float pad = paramLiquidIntensity + 1.0;
        setOffset(outDir.x * pad, outDir.y * pad);
        applyOffset(vertex);
        texCoord0 += outDir * (pad / 256.0);
    }

    // burst tylko w GUI, po marginesach efektow fragmentowych - zoom skaluje quad razem z nimi.
    // Srodek: ekran z ProjMat (ortho: 2/W, -2/H), tytul lezy 24 px (6 px x4) nad srodkiem.
    if (flagBurst && burstT > 0.0 && ProjMat[3][3] != 0.0) {
        float burstP = 1.0 - burstT;
        // przysiad po uderzeniu: w drugiej polowie napis na chwile ok. 12% mniejszy
        float squash = sin(PI * clamp(burstP * 2.0 - 1.0, 0.0, 1.0)) * 0.12;
        float zoom = paramBurstPunch * burstT * burstT * burstT - squash;
        vec2 center = vec2(1.0 / ProjMat[0][0], -1.0 / ProjMat[1][1] - 24.0);
        vec2 jolt = vec2(noise(GameTime * 48000.0), noise(GameTime * 48000.0 + 50.0)) - 0.5;
        setOffset((vertex.x - center.x) * zoom + jolt.x * 12.0 * burstT,
                  (vertex.y - center.y) * zoom + jolt.y * 12.0 * burstT);
        applyOffset(vertex);
    }

    // Save pre-projection position for color effects
    float preX = vertex.x;
    float preY = vertex.y;

    // ========================================
    // Phase 3: Projection
    // ========================================
    if (flagSequentialSpin) {
        processSequentialSpin(vertex, paramSpinSpeed, 0.0);
    } else if (flagSpin) {
        processSpin(vertex, paramSpinSpeed, 0.0);
    } else {
        applyProjection(vertex);
    }

    // ========================================
    // Phase 4: Post-projection effects
    // ========================================
    if (flagWavy) {
        bool isGUI = ProjMat[3][3] != 0.0;
        if (isGUI) {
            // amplituda w px GUI, niezalezna od rozmiaru okna
            gl_Position.y += ProjMat[1][1] * sin(TAU * fract(GameTime * 1200.0 * paramWaveSpeed) + Position.x * paramWaveXFrequency) * paramWaveAmplitude;
        } else {
            float charId = floor(float(gl_VertexID) / 4.0);
            float vid = mod(float(gl_VertexID), 4.0);
            float charX = charId + step(1.5, vid);
            float wave = sin(TAU * fract(GameTime * 1200.0 * paramWaveSpeed) + charX * paramWaveXFrequency * 6.0) * paramWaveAmplitude * 0.05;
            gl_Position.y += ProjMat[1][1] * wave;
        }
    }

    // ========================================
    // Phase 5: Color
    // ========================================
    if (flagAurora) {
        float s = isShadow ? 0.25 : 1.0;
        bool isGUI = ProjMat[3][3] != 0.0;
        float spatialAurora;
        if (isGUI) {
            spatialAurora = preX + preY;
        } else {
            float aCharId = floor(float(gl_VertexID) / 4.0);
            float aVid    = mod(float(gl_VertexID), 4.0);
            float aXt = (aVid == 2.0 || aVid == 3.0) ? 1.0 : 0.0;
            float aYt = (aVid == 1.0 || aVid == 2.0) ? 1.0 : 0.0;
            spatialAurora = (aCharId + aXt) * 6.0 + aYt * 7.0;
        }
        float auroraT = fract(GameTime * 1200.0 * paramAuroraSpeed + spatialAurora * 0.01);
        float third = 1.0 / 3.0;
        vec3 auroraColor;
        float auroraAlpha;
        if (auroraT < third) {
            float lt = auroraT / third;
            auroraColor = mix(paramAuroraColor1, paramAuroraColor2, lt);
            auroraAlpha = mix(paramAuroraColor1A, paramAuroraColor2A, lt);
        } else if (auroraT < 2.0 * third) {
            float lt = (auroraT - third) / third;
            auroraColor = mix(paramAuroraColor2, paramAuroraColor3, lt);
            auroraAlpha = mix(paramAuroraColor2A, paramAuroraColor3A, lt);
        } else {
            float lt = (auroraT - 2.0 * third) / third;
            auroraColor = mix(paramAuroraColor3, paramAuroraColor1, lt);
            auroraAlpha = mix(paramAuroraColor3A, paramAuroraColor1A, lt);
        }
        vec4 texColor = texelFetch(Sampler2, UV2 / 16, 0);
        vertexColor = vec4(auroraColor * s, auroraAlpha * displayColor.a) * texColor;
    } else if (flagRainbow) {
        applyHueColor(paramRainbowSpeed, preX, preY, displayColor.a);
    } else if (flagDynamicGradient) {
        float s = isShadow ? 0.25 : 1.0;
        int dynDir = int(paramDynGradientDirection);

        // GUI uses model-space position so the phase stays stable when other
        // text in the same batch changes (e.g. tab list animations shifting
        // gl_VertexID). World-space text (Text Display) falls back to vertex-id
        // derived coords because Position can be too small to drive a gradient.
        bool isGUI = ProjMat[3][3] != 0.0;
        float spatialX, spatialY;
        if (isGUI) {
            spatialX = preX;
            spatialY = preY;
        } else {
            float dynCharId = floor(float(gl_VertexID) / 4.0);
            float dynVid = mod(float(gl_VertexID), 4.0);
            float dynXt = (dynVid == 2.0 || dynVid == 3.0) ? 1.0 : 0.0;
            float dynYt = (dynVid == 1.0 || dynVid == 2.0) ? 1.0 : 0.0;
            spatialX = (dynCharId + dynXt) * 6.0;
            spatialY = dynYt * 7.0;
        }

        float spatial;
        if      (dynDir == 0) spatial =  spatialY;
        else if (dynDir == 1) spatial =  spatialX + spatialY;
        else if (dynDir == 2) spatial =  spatialX;
        else if (dynDir == 3) spatial =  spatialX - spatialY;
        else if (dynDir == 4) spatial = -spatialY;
        else if (dynDir == 5) spatial = -spatialX - spatialY;
        else if (dynDir == 6) spatial = -spatialX;
        else                  spatial = -spatialX + spatialY;
        float dynT = 1.0 - abs(fract(GameTime * 1200.0 * paramDynGradientSpeed + spatial * 0.01) * 2.0 - 1.0);
        vec3 dynColor = mix(paramDynGradientStart * s, paramDynGradientEnd * s, dynT);
        float dynAlpha = mix(paramDynGradientStartA, paramDynGradientEndA, dynT);
        vec4 texColor = texelFetch(Sampler2, UV2 / 16, 0);
        vertexColor = vec4(dynColor, dynAlpha * displayColor.a) * texColor;
    } else if (flagGradient) {
        float s = isShadow ? 0.25 : 1.0;
        float vid = mod(float(gl_VertexID), 4.0);
        float x_t = (vid == 2.0 || vid == 3.0) ? 1.0 : 0.0;
        float y_t = (vid == 1.0 || vid == 2.0) ? 1.0 : 0.0;
        int gradDir = int(paramGradientDirection);
        float gradT;
        if      (gradDir == 0) gradT = 1.0 - y_t;
        else if (gradDir == 1) gradT = (x_t + (1.0 - y_t)) * 0.5;
        else if (gradDir == 2) gradT = x_t;
        else if (gradDir == 3) gradT = (x_t + y_t) * 0.5;
        else if (gradDir == 4) gradT = y_t;
        else if (gradDir == 5) gradT = ((1.0 - x_t) + y_t) * 0.5;
        else if (gradDir == 6) gradT = 1.0 - x_t;
        else                   gradT = ((1.0 - x_t) + (1.0 - y_t)) * 0.5;
        vec3 gradColor = mix(paramGradientStart * s, paramGradientEnd * s, gradT);
        float gradAlpha = mix(paramGradientStartA, paramGradientEndA, gradT);
        vec4 texColor = texelFetch(Sampler2, UV2 / 16, 0);
        vertexColor = vec4(gradColor, gradAlpha * displayColor.a) * texColor;
    } else {
        vertexColor = displayColor * texelFetch(Sampler2, UV2 / 16, 0);
    }

    // ========================================
    // Phase 5b: Fragment effect outputs
    // ========================================
    fshBaseColor = displayColor;
    fshEffectID = 0.0;
    if (flagOutline) {
        fshEffectID = 1.0;
        fshEffectColor = paramOutlineColor;
        fshEffectParams = vec4(paramOutlineThickness, 0.0, 0.0, 0.0);
    } else if (flagHatch) {
        fshEffectID = 2.0;
        fshEffectColor = paramHatchColor;
        fshEffectParams = vec4(0.0, paramHatchSpeed, paramHatchDensity, 0.0);
    } else if (flagNeon) {
        fshEffectID = 3.0;
        fshEffectColor = paramNeonColor;
        fshEffectParams = vec4(paramNeonIntensity, paramNeonSpeed, 0.0, 0.0);
    } else if (flagSplit) {
        fshEffectID = 5.0;
        fshEffectColor = displayColor;
        fshEffectParams = vec4(paramSplitIntensity, paramSplitSpeed, 0.0, 0.0);
    } else if (flagChromatic) {
        fshEffectID = 6.0;
        fshEffectColor = displayColor;
        fshEffectParams = vec4(paramChromaticIntensity, paramChromaticSpeed, 0.0, 0.0);
    } else if (flagExtrude) {
        fshEffectID = 7.0;
        fshEffectColor   = paramExtrudeColor;
        fshExtrudeColor2 = paramExtrudeColor2;
        fshExtrudeColor3 = paramExtrudeColor3;
        fshEffectParams = vec4(paramExtrudeDepth, paramExtrudeLayers, paramExtrudeUseColor, 0.0);
    } else if (flagNoise) {
        fshEffectID = 8.0;
        fshEffectColor = displayColor;
        fshEffectParams = vec4(paramNoiseIntensity, paramNoiseSpeed, 0.0, 0.0);
    } else if (flagLiquid) {
        fshEffectID = 9.0;
        fshEffectColor = displayColor;
        fshEffectParams = vec4(paramLiquidIntensity, paramLiquidSpeed, 0.0, 0.0);
    } else if (flagWater) {
        fshEffectID = 10.0;
        fshEffectColor = paramWaterColor;
        fshEffectParams = vec4(paramWaterLevel, paramWaterAmplitude, paramWaterSpeed, paramWaterFrequency);
    } else if (flagShine) {
        // Position along the sweep for the whole text, not per glyph: GUI uses the model-space
        // position (like dynamic_gradient); world text falls back to vertex-id coords.
        // x + y/2 slants the band like "/" (GUI y grows downwards). .w is interpolated per fragment.
        float shineX = preX;
        float shineY = preY;
        if (ProjMat[3][3] == 0.0) {
            float shineVid = mod(float(gl_VertexID), 4.0);
            shineX = (floor(float(gl_VertexID) / 4.0) + ((shineVid == 2.0 || shineVid == 3.0) ? 1.0 : 0.0)) * 6.0;
            shineY = ((shineVid == 1.0 || shineVid == 2.0) ? 1.0 : 0.0) * 7.0;
        }
        fshEffectID = 11.0;
        // Cien dostaje blysk przyciemniony jak kolor tekstu, inaczej swiecilby na jasno pod napisem.
        fshEffectColor = isShadow ? vec4(paramShineColor.rgb * 0.25, paramShineColor.a) : paramShineColor;
        fshEffectParams = vec4(paramShineSpeed, paramShineWidth, 0.0, shineX + shineY * 0.5);
    }

    fshGlyphT0 = vec3(0.0);
    fshGlyphT1 = vec3(0.0);
    fshGlyphT2 = vec3(0.0);
    fshGlyphT3 = vec3(0.0);
    if (flagOutline || flagNeon || flagHatch || flagSplit ||
        flagChromatic || flagExtrude || flagNoise || flagLiquid || flagWater) {
        int vid_glyph = gl_VertexID % 4;
        if (vid_glyph == 0) fshGlyphT0 = vec3(UV0, 1.0);
        if (vid_glyph == 1) fshGlyphT2 = vec3(UV0, 1.0);
        if (vid_glyph == 2) fshGlyphT1 = vec3(UV0, 1.0);
        if (vid_glyph == 3) fshGlyphT3 = vec3(UV0, 1.0);
    }

    // ========================================
    // Phase 6: Alpha modifiers
    // ========================================
    if (flagFade && paramFadeSpeed > 0.0) {
        float fadeAlpha = sin(TAU * fract(GameTime * 1200.0 * paramFadeSpeed));
        fadeAlpha = (fadeAlpha + 1.0) * 0.5;
        vertexColor.a *= fadeAlpha;
    }

    // ========================================
    // Phase 7: Depth bias to prevent z-fighting with background.
    // Skip in GUI (orthographic) — 1.21.6+ uses tight z-steps for layered UI
    // (tooltips, autocomplete), so a 0.001 nudge breaks layering. The bias is
    // only needed for world-space text (Text Display) where z-fight is real.
    // ========================================
    if (ProjMat[3][3] == 0.0) {
        // Upstream ee2244e (fix #16: z -= w * 0.001) is intentionally not ported. On 1.21.11
        // (standard depth, LEQUAL, near 0.05) it pulls world text through walls: ~3 blocks at 20 m,
        // ~17 at 50 m. #16 is Sampler2 binding, not depth. Revisit for upstream's 26_2 overlay (formats 88+, uses +=).
        gl_Position.z -= 0.001;
    }

    // ========================================
    // Phase 7b: Apply text display opacity (Color.a) uniformly.
    // currentBaseColor.a holds the user override (defaults to 1.0); text
    // display opacity is applied here so every color path respects it.
    // ========================================
    // beat i burst: Color.a to ich zegar, nie przezroczystosc. fshDisplayAlpha mnoza
    // sciezki fragmentowe (chromatic, shine), wiec dostaje to samo krycie.
    if (flagBurst) {
        // pelne krycie po ok. 1/4 fade-in: uderzenie ma byc twarde, nie jak zanikanie
        float burstAlpha = min(1.0, Color.a * 4.0);
        vertexColor.a *= burstAlpha;
        fshDisplayAlpha = burstAlpha;
    } else if (flagBeat) {
        fshDisplayAlpha = 1.0;
    } else {
        vertexColor.a *= Color.a;
    }

    // ========================================
    // Phase 8: Finalize
    // ========================================
    finalize();
}
