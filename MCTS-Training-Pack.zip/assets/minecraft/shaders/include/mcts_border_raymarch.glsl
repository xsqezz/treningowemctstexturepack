#moj_import <minecraft:mcts_border_config.glsl>

#define V_APPROX 100000

#ifndef PI
#define PI 3.14159265359
#endif

float REDNESS = 0.0;

bool intersectRayCylinder(vec3 ro, vec3 rd, vec3 center, float radius, float height, out vec3 first_hit, out vec3 second_hit, out bool second_miss) {
    second_miss = true;
    first_hit = second_hit = vec3(0.0);
    center.z -= height;

    const vec3 ca = vec3(0.0, 0.0, 1.0);
    
    vec3 oc = ro - center;
    
    vec3 rd_proj = rd - dot(rd, ca) * ca;
    vec3 oc_proj = oc - dot(oc, ca) * ca;
    
    float a = dot(rd_proj, rd_proj);
    float b = 2.0 * dot(rd_proj, oc_proj);
    float c = dot(oc_proj, oc_proj) - radius * radius;
    
    float discriminant = b * b - 4.0 * a * c;
    if (discriminant < 0.0) {
        return true;
    }
    
    float sqrt_discriminant = sqrt(discriminant);
    float t0 = (-b - sqrt_discriminant) / (2.0 * a);
    float t1 = (-b + sqrt_discriminant) / (2.0 * a);
    
    if (t0 > t1) {
        float temp = t0;
        t0 = t1;
        t1 = temp;
    }
    
    if (t0 < 0.0) {
        t0 = t1;  
        if (t0 < 0.0) {
            return true; 
        }
    }

    float z0 = ro.z + t0 * rd.z;
    float z1 = ro.z + t1 * rd.z;
    
    bool validT0 = z0 >= center.z && z0 <= center.z + height;
    bool validT1 = z1 >= center.z && z1 <= center.z + height;
    
    if (!validT0 && !validT1) {
        return true;
    }

    vec3 first_intersection = ro + t0 * rd;
    vec3 second_intersection = ro + t1 * rd;

    if (validT0 && validT1) {
        if (t0 != t1) {
            second_miss = false;
            second_hit = second_intersection;
        }
        first_hit = first_intersection;
    } else if (validT0) {
        first_hit = first_intersection;
    } else {
        first_hit = second_intersection;
    }
    return false;
}

float tick(float x, float y) {
    return x - mod(x, y);
}

vec4 fade_out(vec4 inColor, float vertexDistance, float fogStart, float fogEnd) {
    if (vertexDistance > fogEnd) {
            discard;
    }
    if (vertexDistance <= fogStart) {
        return inColor;
    }

    float fogValue = smoothstep(fogStart, fogEnd, vertexDistance);
    return vec4(inColor.rgb, mix(inColor.a, 0, fogValue));
}

vec4 fade_out_with_defaults(vec4 inColor, float vertexDistance) {
    float end = clamp(FogRenderDistanceEnd, MIN_FADE_END, MAX_FADE_END);

    return fade_out(inColor, vertexDistance, end - FADE_LENGTH, end);
}

vec4 color_from_pos(vec3 o_pos, float depth, float radius) {
    float Time = GameTime * RIPPLE_SPEED;
    vec3 pos = o_pos.xzy;
    vec3 borderColor = mix(vec3(15, 95, 185), vec3(227, 98, 110), REDNESS)/255.;
    vec4 color = vec4(borderColor, BORDER_ALPHA);
    float horizontal = (atan(pos.x, pos.z) + PI) / (2*PI);

    float circumference = 2*PI*radius;

    float low = pow(2, int(log2(circumference/MIN_TILE_WIDTH+0.1)));
    float up = low*2;
    float c = circumference/MIN_TILE_WIDTH+0.1;
    float stretch = (c - low) / (up - low);
    
    float tileWidth = circumference/low;

    vec2 bigTileCoords;
    if (stretch > 0.95) {
        bigTileCoords = vec2(
            mod(horizontal * circumference, tileWidth),
            mod(pos.y, 3)
            );
        tileWidth /= 2;
    }

    vec2 tileCoords = vec2(
        mod(horizontal * circumference, tileWidth),
        mod(pos.y, 3)
        );

    float tileMargin = (sin((tick(-pos.y, 3))/10.+Time*PI*2)/2+0.5)/2+0.05;
    
    // apply on tile
    if (all(greaterThan(tileCoords, vec2(tileMargin, tileMargin))) && all(lessThan(tileCoords, vec2(tileWidth-tileMargin, 3-tileMargin)))) {
        color += mix(vec4(1, 1, 2, 0.5), vec4(2, 1, 1, 0.5), REDNESS)*0.125*clamp((depth-10)/20, 0, 1)*clamp((60-pos.y)/40, 0, 1);
    } else if (stretch > 0.95 && all(greaterThan(bigTileCoords, vec2(tileMargin, tileMargin))) && all(lessThan(bigTileCoords, vec2(tileWidth*2-tileMargin, 3-tileMargin)))) {
        color += (1-(stretch - 0.95) *20) * mix(vec4(1, 1, 2, 0.5), vec4(2, 1, 1, 0.5), REDNESS)*0.125*clamp((depth-10)/20, 0, 1)*clamp((60-pos.y)/40, 0, 1);
    }

    // nearby squares - oba czlony gasi clamp((15-depth)/10, 0, 1), wiec dalej niz 15 blokow
    // daja zero. Bez straznika kazdy piksel sciany liczy sin i mody na darmo.
    if (depth < 15) {
        vec2 squareCoords = vec2(mod(horizontal, 0.0625/radius)/(0.0625/radius), mod(pos.y, 0.4) / 0.4);
        float squareSize = (sin((tick(pos.y, 0.4))+tick(horizontal, 0.0625/radius)/(0.0625/radius)*0.4+Time*PI*2)/2+0.5)/4+0.05;
        if (all(greaterThan(squareCoords, vec2(squareSize, squareSize))) && all(lessThan(squareCoords, vec2(1-squareSize, 1-squareSize)))) {
            color += mix(vec4(0.2, 0.2, 3.5, 3), vec4(4, 0.1, 0.0, 3), REDNESS)*0.125*clamp((15-depth)/10, 0, 1);
            color *= mix(vec4(1), vec4(1, 0.4, 0.5, 1), clamp((15-depth)/10, 0, 1) * REDNESS);
        }
    }

    // Kafle i kwadraty mają rozjaśniać border, a nie go zasłaniać: oba człony wyżej dodają
    // też alfę (kwadraty aż +0.375 z bliska), przez co krycie zależało od odległości gracza.
    // Kolor zostaje, krycie wraca do bazowego.
    color.a = min(color.a, BORDER_ALPHA);

    float fade_t = (o_pos.z + HEIGHT - FADEOFF) / FADEOFF + 1;
    color.a *= clamp(fade_t, 0, 1);

    return fade_out_with_defaults(color, depth);
}

vec4 ray(in vec3 ro, in vec3 rd, inout float depth, float radius) {
    bool second_miss;
    vec3 pos;
    vec3 second_pos;
    if (!intersectRayCylinder(ro, rd, vec3(0.0, 0.0, 0.0), radius, HEIGHT, pos, second_pos, second_miss)) {
        depth = length(pos - ro);
    } else {
        return vec4(0);
    }

    return color_from_pos(pos, depth, radius);
}

vec4 ray2(in vec3 ro, in vec3 rd, inout float depth, float radius) {
    bool second_miss;
    vec3 pos;
    vec3 second_pos;
    if (!intersectRayCylinder(ro, rd, vec3(0.0, 0.0, 0.0), radius, HEIGHT, pos, second_pos, second_miss) && !second_miss) {
        depth = length(second_pos - ro);
    } else {
        return vec4(0);
    }

    return color_from_pos(second_pos, depth, radius);
}

void writeDepth(vec3 Pos) {
    vec4 ProjPos = ProjMat * vec4(Pos, 1);
    gl_FragDepth = ProjPos.z / ProjPos.w * 0.5 + 0.5;
}

void raymarch(bool behind) {
    vec3 Pos1 = round(ray_pos1.xyz * V_APPROX / ray_pos1.w) / V_APPROX;
    vec3 Pos2 = round(ray_pos3.xyz * V_APPROX / ray_pos3.w) / V_APPROX;
    vec3 Pos3 = gl_PrimitiveID % 2 == 0 ? round(ray_pos2.xyz * V_APPROX / ray_pos2.w) / V_APPROX : round(ray_pos4.xyz * V_APPROX / ray_pos4.w) / V_APPROX;

    vec3 tangent = normalize(gl_PrimitiveID % 2 == 0 ? Pos3 - Pos1 : Pos2 - Pos3);
    vec3 bitangent = normalize(gl_PrimitiveID % 2 == 1 ? Pos1 - Pos3 : Pos3 - Pos2);
    vec3 normalT = normalize(cross(tangent, bitangent));

    mat3 TBN = mat3(tangent, bitangent, normalT);

    vec3 rawCenter = (Pos1 + Pos2) / 2;
    vec3 center = rawCenter * TBN;
    vec3 dir = normalize(ray_glPos);
    vec3 dirTBN = normalize(ray_glPos * TBN);

    if (ProjMat[3][0] == -1) {
        center = vec3(-ray_glPos.xy + rawCenter.xy, rawCenter.z) * TBN;
        dir = vec3(0, 0, -1);
        dirTBN = normalize(dir * TBN);
    }

    float border_radius = length(Pos1 - Pos3); 
    REDNESS = clamp(length(Pos2 - Pos3), 1.0, 2.0) - 1.0;

    float min_depth = MAX_DEPTH;

    center.z -= SHIFT_Y;

    fragColor = behind ? ray2(-center, dirTBN, min_depth, border_radius) : ray(-center, dirTBN, min_depth, border_radius);

    if (min_depth == MAX_DEPTH) {
        discard;
    }

    //gl_FragDepth = min_depth;

    writeDepth(dir * min_depth);
}