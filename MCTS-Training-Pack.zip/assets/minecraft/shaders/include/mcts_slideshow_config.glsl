#define SS_BG_COLOR        (vec3(23.0, 23.0, 29.0) / 255.0)
#define SS_STAR_COLOR      (vec3(23.0, 23.0, 29.0) / 255.0 * 1.45)
#define SS_BG_ALPHA        1.0
#define SS_BG_CELL         vec2(0.24, 0.12)
#define SS_BG_PERIOD       6.0
#define SS_STAR_RADIUS     0.028
#define SS_STAR_SHAPE      3.0
#define SS_STAR_ROUND      0.45
#define SS_STAR_ROTATION   0.0
#define SS_SLIDE_HEIGHT    0.72
#define SS_SLIDE_POS       vec2(0.0, 0.0)
#define SS_IN_SCALE        0.96
#define SS_OUT_SCALE       0.45
#define SS_OUT_ALPHA       1.0
#define SS_SWITCH_X1       0.42
#define SS_SWITCH_Y1       0.0
#define SS_SWITCH_X2       0.58
#define SS_SWITCH_Y2       1.0
#define SS_END_SCALE       0.96
#define SS_OUTRO_SPLIT     0.5
#define SS_LOGO_SLIDE      255
#define SS_LOGO_SCALE      1.0
#define SS_LOGO_SPLIT      0.4
#define SS_LOGO_IN_SCALE   0.55
#define SS_LOGO_OVERSHOOT  1.7
#define SS_LOGO_OUT_BG     0.6
#define SS_LOGO_OUT_SCALE  1.05
#define SS_LOGO_HALO_COLOR (vec3(255.0, 205.0, 66.0) / 255.0)
#define SS_LOGO_HALO_SIZE  vec2(0.55, 0.8)
#define SS_LOGO_HALO_STRENGTH 0.4
#define SS_LOGO_HALO_PULSE 0.25
#define SS_LOGO_HALO_PERIOD 2.5
#define SS_LOGO_SHINE_STRENGTH 0.55
#define SS_LOGO_SHINE_WIDTH 0.1
#define SS_LOGO_SHINE_SLANT 0.6
#define SS_LOGO_SHINE_PERIOD 2.0
#define SS_BAR_WIDTH       0.5
#define SS_BAR_HEIGHT      0.011
#define SS_BAR_OFFSET      0.06
#define SS_BAR_MARGIN      0.004
#define SS_BAR_TRACK       (vec3(14.0, 14.0, 19.0) / 255.0)
#define SS_BAR_LEFT        (vec3(255.0, 205.0, 66.0) / 255.0)
#define SS_BAR_RIGHT       (vec3(238.0, 128.0, 24.0) / 255.0)
#define SS_BAR_TRACK_ALPHA 0.85
#define SS_GLOW_COLOR      vec3(1.0, 1.0, 1.0)
#define SS_GLOW_LINE       0.004
#define SS_GLOW_WIDTH      0.03
#define SS_GLOW_STRENGTH   0.55
#define SS_GLOW_RADIUS     0.004
#define SS_GLOW_PULSE      0.25
#define SS_GLOW_PULSE_PERIOD 2.0
#define SS_GLOW_SWEEP      0.7
#define SS_GLOW_SWEEP_WIDTH 0.12
#define SS_GLOW_SWEEP_PERIOD 4.0
#define SS_AA              0.6
#define SS_CLOCK           (GameTime * 1200.0)
