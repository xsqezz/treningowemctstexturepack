// ================================================================
//  MCTS screen effects - fragment stage
// ----------------------------------------------------------------
//  mcts_screen_fragment() returns true when the fragment belongs to a
//  screen effect (animated frame or one of the full-screen overlays)
//  and it has written the colour; false means "ordinary text", which
//  the text-effect pipeline then renders.
//
//  Requires, in the including shader, before this import:
//      uniform sampler2D Sampler0;
//      #moj_import <minecraft:dynamictransforms.glsl>  (ColorModulator)
//      #moj_import <minecraft:globals.glsl>            (ScreenSize, GameTime)
//      #moj_import <minecraft:mcts_screen_effects_ids.glsl>
//      #moj_import <minecraft:mcts_screen_utils.glsl>
//      #moj_import <minecraft:mcts_loading_screen.glsl>
//      in vec4 vertexColor; in vec2 texCoord0;
//      the ss* varyings declared by the core shader
// ================================================================


#define MCTS_SPIKES_SPEED      2000.0
#define MCTS_SPIKES_RADIUS     0.07
#define MCTS_SPIKES_COUNT      50.0
#define MCTS_SPIKES_BLUR       50.0  // bigger value -> less blur
#define MCTS_SPIKES_BLUR_BIAS  0.0   // addition to transparency in blur

bool mcts_screen_fragment(out vec4 color) {
    bool handled = false;
    color = vec4(0.0);

    // Rebuild the glyph's texel rectangle inside the 256x256 font page
    // from the two corner UVs the vertex stage stored.
    vec2 P1 = round(ssP1 / (ssVert == 0 ? 1.0 - ssCorner.x : 1.0 - ssCorner.y)); // right-up corner
    vec2 P2 = round(ssP2 / (ssVert == 0 ? ssCorner.y : ssCorner.x));            // left-down corner

    ivec2 res = ivec2(abs(P1 - P2)); // resolution of the glyph
    ivec2 stp = ivec2(min(P1, P2));  // left-up corner of the glyph

    vec4 test = texture(Sampler0, stp / 256.0) * 255.0;

    // --- animated frame ------------------------------------------
    if (test.a == MCTS_ANIMATED_FRAME_MARK) {
        ivec2 frames = ivec2(res / test.gb);
        vec2 uv = (texCoord0 * 256.0 - stp) / frames.x;

        if (uv.x > test.y || uv.y > test.z)
            discard;

        int time = int(GameTime * 1000.0 * test.x) % int(frames.x * frames.y);

        uv = stp + mod(uv, test.yz) + vec2(time % frames.x, time / frames.x % frames.y) * test.yz;
        color = texture(Sampler0, uv / 256.0) * vertexColor * ColorModulator;
        handled = true;
    }

    if (ssEffect == 0)
        return handled;

    vec2 centerUV = gl_FragCoord.xy / ScreenSize - 0.5;
    float Ratio = ScreenSize.y / ScreenSize.x;

    switch (ssEffect)
    {
        case MCTS_EFFECT_VIGNETTE:
        {
            color = vec4(0.0, 0.0, 0.0, clamp(length(centerUV * vec2(0.8, 0.5 / (1.0 - vertexColor.a))) - 0.6, 0.0, 1.0));
        }
        break;
        case MCTS_EFFECT_SPIKES:
        {
            color = vec4(0.0);

            float angle = (atan(centerUV.y, centerUV.x) / PI / 2.0 + 0.5) * MCTS_SPIKES_COUNT;
            float Time = GameTime * MCTS_SPIKES_SPEED + hash(int(angle)) % 100 * 64.2343;
            float s = (abs(fract(angle) - 0.5) * 20.0 / MCTS_SPIKES_COUNT - 0.2) * length(centerUV) + MCTS_SPIKES_RADIUS + (1.0 - vertexColor.a) * 0.05 + abs(fract(Time) - 0.5) * 0.25;
            if (s < 0.0)
            {
                color = vec4(1.0, 1.0, 1.0, clamp(-s * MCTS_SPIKES_BLUR + MCTS_SPIKES_BLUR_BIAS, 0.0, 1.0));
                break;
            }
        }
        break;
        case MCTS_EFFECT_DIAMOND_GRID:
        {
            vec2 grid = (ivec2(gl_FragCoord.xy / 32.0) * 32);
            vec2 inGrid = gl_FragCoord.xy - grid - 16.0;
            float size;

            switch (int(vertexColor.b * 255.0))
            {
                case 0:
                    size = grid.x / ScreenSize.x;
                    break;
                case 1:
                    size = 1.0 - grid.x / ScreenSize.x;
                    break;
                case 2:
                    size = grid.y / ScreenSize.y;
                    break;
                default:
                    size = 1.0 - grid.y / ScreenSize.y;
                    break;
            }

            size = (size - vertexColor.a * 2.0 + 1.0) * 32.0;

            color = (abs(inGrid.x) + abs(inGrid.y) > size) ? vec4(0.0, 0.0, 0.0, 1.0) : vec4(0.0);
        }
        break;
        case MCTS_EFFECT_DITHER:
        {
            ivec2 grid = ivec2(gl_FragCoord.xy / 32.0) * 32;

            color = abs(hash(grid.x ^ hash(grid.y)) % 0x100) + 10 < int(vertexColor.a * (length(grid / ScreenSize.xy - 0.5) * 2.0 + 1.0) * 0x100) ? vec4(vertexColor.rgb, 1.0) : vec4(0.0);
        }
        // NOTE: no `break` here - upstream falls through into the radial
        // fade on purpose-looking-accident. Kept as-is so effect 5 keeps
        // rendering exactly like it does in the stand-alone pack.
        case MCTS_EFFECT_RADIAL_FADE:
        {
            float Time = cos(vertexColor.a * PI / 2.0);
            color = vec4(vertexColor.rgb, (length((gl_FragCoord.xy / ScreenSize - 0.5) / vec2(ScreenSize.y / ScreenSize.x, 1.0)) + 0.1 - Time) * (1.0 - Time) * 100.0);
        }
        break;
        case MCTS_EFFECT_SPINNER:
        {
            vec2 uv = centerUV / vec2(Ratio, 1.0);
            color = vec4(0.0);

            float radius = length(uv);

            if (radius >= 0.05 && radius < 0.08 && vertexColor.a >= 0.99)
            {
                float angle = fract(-atan(uv.y, uv.x) / PI * 0.5 + 0.5 - GameTime * 1000.0);
                color = vec4(1.0, 1.0, 1.0, angle);
            }
        }
        break;
        case MCTS_EFFECT_LOADING:
        {
            // Corner marker pixel: RGBA = (role, 0, 0, 4)
            //   role 0 = backdrop + bar + iris, 1..4 = logo tile TL/TR/BL/BR
            vec4 mark = texture(Sampler0, (vec2(stp) + 0.5) / 256.0) * 255.0;

            // Skip the font shadow pass (dim duplicate of every glyph)
            if (max(vertexColor.r, max(vertexColor.g, vertexColor.b)) < 0.5)
            {
                color = vec4(0.0);
                break;
            }

            // Logo tiles inside a slideshow title (#FF04NN / #FF05NN): the
            // slideshow fades them out itself, no iris.
            if (ssHostedLoadingGlyph(vertexColor) && int(round(mark.r)) != 0)
            {
                color = slideshowLogoTile(vertexColor, int(round(mark.r)) - 1, vec2(stp), vec2(res));
                gl_FragDepth = 0.0;
                break;
            }

            // One glyph set for both directions: the title COLOR picks the
            // mode - blue < 254/255 (#FFFFFE, looks white) = outro.
            // (mark.g kept for back-compat with any old *_out textures.)
            bool outro = mark.g > 128.0 || vertexColor.b < 0.998;

            if (int(round(mark.r)) == 0)
                color = loadingScreen(vertexColor, outro);
            else
                color = loadingLogoTile(vertexColor, outro, int(round(mark.r)) - 1, vec2(stp), vec2(res));

            // Render ON TOP of chat / hotbar / other depth-tested UI drawn
            // after the title: claim the nearest possible depth.
            gl_FragDepth = 0.0;
        }
        break;
        case MCTS_EFFECT_STAIN:
        {
            color = vec4(0.0);
            color = sampleStain(color, vertexColor, stp, vec2(-0.1, -0.2));
            color = sampleStain(color, vertexColor, stp, vec2(-0.05, 0.2));
            color = sampleStain(color, vertexColor, stp, vec2(0.2, -0.1));
        }
        break;
        case MCTS_EFFECT_SLIDESHOW:
        {
            vec4 mark = round(texture(Sampler0, (vec2(stp) + 0.5) / 256.0) * 255.0);

            if (mark.b == 0.0)
                color = slideshowBackground(vertexColor);
            else
                color = slideshowTile(mark, vertexColor, vec2(stp), vec2(res));

            gl_FragDepth = 0.0;
        }
        break;
        case MCTS_EFFECT_SLIDESHOW_BAR:
        {
            color = slideshowBar(vertexColor);
            gl_FragDepth = 0.0;
        }
        break;
    }

    return true;
}
