// Shine effect (MCTS addition, not in upstream Text Effects): a soft diagonal
// highlight band that sweeps across the whole text on top of the display
// colour, then pauses - the gleam of a gold bar. The slots run WITH_SHADOW:
// the shadow gets the same band, darkened by 0.25 like the text colour.
//
// fshEffectParams.x = speed      (sweeps per second, Hz: 0.4 = one every 2.5 s)
// fshEffectParams.y = half-width (of the band, in text pixels)
// fshEffectParams.w = position   (along the sweep, in text pixels; the vertex
//                                 stage writes it per vertex and it is
//                                 interpolated per fragment - apply_effect.glsl)

// Text pixels between two bands (a glyph is ~6): one band at a time on a title.
#define SHINE_PERIOD 160.0
// How far the band pulls the colour towards the shine colour at its centre.
#define SHINE_STRENGTH 0.9

// Band strength (0..1) at this fragment; also used by the BetterHud HUD path in betterhud/shaders/text.fsh.
float shineMask(vec4 effectParams, float gameTime) {
    float speed = effectParams.x;
    float halfWidth = max(effectParams.y, 0.5);

    // Distance (text px) from the nearest band centre; bands travel towards +position.
    float phase = effectParams.w - gameTime * 1200.0 * speed * SHINE_PERIOD;
    float dist = abs(mod(phase, SHINE_PERIOD) - SHINE_PERIOD * 0.5);
    return 1.0 - smoothstep(0.0, halfWidth, dist);
}

void applyShineEffect(vec2 uv,
                      vec4 baseColor,
                      vec4 effectColor,
                      vec4 effectParams,
                      float gameTime,
                      sampler2D tex,
                      out vec4 result) {
    float currentA = texture(tex, uv).a;
    if (currentA < 0.1) {
        discard;
    }

    float mask = shineMask(effectParams, gameTime) * SHINE_STRENGTH * effectColor.a;

    result = vec4(mix(baseColor.rgb, effectColor.rgb, mask), currentA * baseColor.a);
}
