const int TYPE_DISCARD = -1;
const int TYPE_VANILLA = 0;
const int TYPE_BORDER = 1;
const int TYPE_BORDER_INNER = 2;
const int TYPE_STAGE_LIGHT = 3;
