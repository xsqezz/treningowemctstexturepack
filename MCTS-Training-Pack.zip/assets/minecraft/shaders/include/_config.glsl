// ============================================================
//  TEXT EFFECTS CONFIGURATION
// ============================================================
//  Colour -> effect mappings. One colour per effect, in the order of the
//  upstream effect table; every effect with its default parameters.
//  The comment after each opening line is the effect name that
//  /mcts shader offers on TAB (MCTSController reads this file).
//
//  Syntax:
//      TEXT_EFFECT(rgb(R, G, B))             { apply_x(); }  // main text only
//      TEXT_EFFECT_WITH_SHADOW(rgb(0xRRGGBB)) { apply_x(); }  // main text + its shadow
//
//  TEXT_EFFECT matches the text colour EXACTLY (RGB, alpha ignored).
//  TEXT_EFFECT_WITH_SHADOW(X) also fires on ANY vertex colour equal to
//  floor(X / 4) per channel: the drop shadow of every colour in the same
//  4-step bucket, and plain text drawn in that dark colour. E.g. #FEFEFE
//  or #FCFCFC would catch the shadow of all white text, #FFFF56 (the
//  "Shadow Support" example in upstream CONFIGURATION.md) that of yellow.
//
//  Use only #F8F8xx, xx a multiple of 4 from 0x54 to 0xD8 (34 slots).
//  Their shadows are #3E3E15..#3E3E36: 0x3E never occurs in a legacy-colour shadow
//  (00/15/2A/3F), F8-FB stays out of the white bucket FC-FF, and step 4
//  gives each effect its own shadow bucket. Never use as ordinary text
//  colours anywhere (plugins, configs): R and G in F8-FB (their shadows
//  hit these buckets) or #3E3Exx (they are the shadow keys themselves).
//
//  The "Start za" countdown has its own family #F8F4xx, xx = 4 * N for the
//  number N shown (1..10, 11 = the "Start za" title, 12 = /mcts shader preview,
//  13 = START; shadows #3E3D01..#3E3D0D).
//  Same rules: never use R F8-FB with G F4-F7, or #3E3Dxx, as ordinary
//  text colours.
//  apply_beat ignores text opacity (Color.a is its clock): only for titles
//  with fadeOut 0, never chat, name tags or text displays.
//
//  Units: every speed is in Hz (shake, glitch, noise: new positions per
//  second, max 60), distances in GUI px at 1x (titles are drawn 4x,
//  subtitles 2x); 0 stops an effect. Ranges: /mcts shader (ShaderConfig).
//  Slot names say what a slot is used for; the colour is its apply_color.
//
//  Full effect list and parameters:
//      https://github.com/TheSalts/Text_Effects/blob/main/CONFIGURATION.md
//
//  Effects that move glyphs or change their colour run WITH_SHADOW, so the
//  shadow follows the text. Fragment effects (outline .. water) draw on the
//  main text only. The trigger colours are yellowish, so effects that do not
//  paint the text themselves get apply_color(white).
//  shine is an MCTS effect (shine_effect.glsl), not part of upstream; it runs
//  WITH_SHADOW so the shadow is the darkened text colour, not grey.
//  Free slots: none.
//
//  Effects skip see-through text (vanilla rendertype_text_see_through):
//  a non-sneaking name tag keeps a static raw-colour copy, the only part
//  seen through walls, and see_through text displays get no effect. Keep
//  moving, blinking and fade effects off colours used in name tags.
//
// ------------------------------------------------------------
//  RESERVED COLOURS - do NOT map effects to these, the MCTS screen
//  effects in rendertype_text claim them:
//      #FBFFFF  (251, 255, 255)  plain white, no lightmap
//      #3E3F3F  ( 62,  63,  63)  hidden glyph
//      #FFFEFD  (255, 254, 253)  CustomNameplates 1px shift
//      #FFFFFE  (255, 255, 254)  loading screen: outro direction
//      #FF5555  (255,  85,  85)  scoreboard sidebar red (number removal)
//  Also avoid R 248-251 with G,B 252-255 (#FBFFFF among them): their shadow,
//  floor(c/4), is #3E3F3F, which gets hidden - such text has no shadow.
// ============================================================

// --- glyph motion ------------------------------------------

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F854)) { // shake
    apply_shake(2.67, 0.1);
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F858)) { // wavy
    apply_wavy();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F85C)) { // rainbow
    apply_rainbow();
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F860)) { // bouncy
    apply_bouncy();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F864)) { // blinking
    apply_blinking();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F868)) { // pulse
    apply_pulse();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F86C)) { // spin
    apply_spin();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F870)) { // sequential_spin
    apply_sequential_spin();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F874)) { // fade
    apply_fade();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F878)) { // iterating
    apply_iterating();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F87C)) { // glitch
    apply_glitch();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F880)) { // scale
    apply_scale(1.0, 1.0, 1.0);
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F884)) { // offset
    apply_offset(0.0, -4.0);
    apply_color(rgb(255, 255, 255));
}

// --- colour --------------------------------------------------

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F888)) { // gradient
    apply_gradient();
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F88C)) { // dynamic_gradient
    apply_dynamic_gradient();
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F890)) { // lava
    apply_lava();
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F894)) { // color
    apply_color(rgb(255, 80, 80));
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F898)) { // aurora
    apply_aurora(rgb(0xFFCA00), rgb(0xFFF300), rgb(0xFFCA00), 1.0);
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F89C)) { // split
    apply_split();
    apply_color(rgb(255, 255, 255));
}

// --- fragment (main text only) -------------------------------

TEXT_EFFECT(rgb(0xF8F8A0)) { // outline
    apply_outline();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT(rgb(0xF8F8A4)) { // hatch
    apply_hatch();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT(rgb(0xF8F8A8)) { // neon
    apply_neon();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT(rgb(0xF8F8AC)) { // chromatic
    apply_chromatic();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT(rgb(0xF8F8B0)) { // extrude
    apply_extrude();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT(rgb(0xF8F8B4)) { // noise
    apply_noise();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT(rgb(0xF8F8B8)) { // liquid
    apply_liquid();
    apply_color(rgb(255, 255, 255));
}

TEXT_EFFECT(rgb(0xF8F8BC)) { // water
    apply_water();
    apply_color(rgb(60, 60, 80));
}

// --- MCTS ------------------------------------------------------

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F8C0)) { // shine_punkty
    apply_shine();
    apply_color(rgb(255, 174, 0));   // #FFAE00 - zloty jak punkty na HUD-zie
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F8C4)) { // shine_tytul
    apply_shine();
    apply_color(rgb(255, 224, 84));  // #FFE054 - lekko zoltawy, np. title "Runda X"
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F8C8)) { // shine_start
    apply_shine();
    apply_color(rgb(80, 255, 64));   // #50FF40 - zielony jak tytul START
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F8CC)) { // shine_miejsce1
    apply_shine();
    apply_color(rgb(255, 215, 0));   // #FFD700 - 1. miejsce
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F8D0)) { // shine_miejsce2
    apply_shine();
    apply_color(rgb(192, 192, 192)); // #C0C0C0 - 2. miejsce
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F8D4)) { // shine_miejsce3
    apply_shine();
    apply_color(rgb(205, 127, 50));  // #CD7F32 - 3. miejsce
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F8D8)) { // shake_alarm
    apply_shake();
    apply_color(rgb(255, 23, 68));   // #FF1744 - czerwony alarm, np. title "Koniec czasu!"
}

// --- MCTS: "Start za" countdown -------------------------------
//  One slot per number shown, shake grows with countdown.ogg: a beat per
//  second at 10-9, busier at 8-7, eighths at 6-4, densest and loudest at 3-1.
//  Colour runs white -> #FFE054 -> #FF1744 (alarm red), 3-1 also grow.
//  apply_beat punches each number in on its beat: the title is sent on the
//  beat and its fade-in (roundCountdown fadeIn) is the clock.

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F42C)) { // countdown_title
    apply_beat(0.0);                    // tylko nieprzezroczysty - fade-in nie mruga co sekunde
    apply_color(rgb(170, 170, 170));   // #AAAAAA
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F428)) { // countdown_10
    apply_shake(13.33, 0.4);
    apply_beat(0.30);
    apply_color(rgb(255, 255, 255));   // #FFFFFF
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F424)) { // countdown_9
    apply_shake(13.33, 0.5);
    apply_beat(0.30);
    apply_color(rgb(255, 248, 217));   // #FFF8D9
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F420)) { // countdown_8
    apply_shake(26.67, 1.1);
    apply_beat(0.35);
    apply_color(rgb(255, 241, 179));   // #FFF1B3
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F41C)) { // countdown_7
    apply_shake(26.67, 1.2);
    apply_beat(0.35);
    apply_color(rgb(255, 234, 141));   // #FFEA8D
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F418)) { // countdown_6
    apply_shake(40.0, 1.6);
    apply_beat(0.40);
    apply_color(rgb(255, 227, 103));   // #FFE367
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F414)) { // countdown_5
    apply_shake(40.0, 1.7);
    apply_beat(0.40);
    apply_color(rgb(255, 202, 82));   // #FFCA52
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F410)) { // countdown_4
    apply_shake(40.0, 1.8);
    apply_beat(0.40);
    apply_color(rgb(255, 157, 79));   // #FF9D4F
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F40C)) { // countdown_3
    apply_shake(53.33, 2.2);
    apply_scale(1.15);
    apply_beat(0.55);
    apply_color(rgb(255, 112, 75));   // #FF704B
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F408)) { // countdown_2
    apply_shake(53.33, 2.4);
    apply_scale(1.30);
    apply_beat(0.55);
    apply_color(rgb(255, 68, 72));   // #FF4448
}

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F404)) { // countdown_1
    apply_shake(53.33, 2.6);
    apply_scale(1.45);
    apply_beat(0.55);
    apply_color(rgb(255, 23, 68));   // #FF1744
}

// --- MCTS: START -------------------------------------------------
//  roundStarted: fadeIn is the burst clock (like beat), sent on the last hit
//  of countdown.ogg. burst only animates titles.

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F434)) { // burst_start
    apply_shine();
    apply_burst(2.5);
    apply_color(rgb(80, 255, 64));    // #50FF40
}

// --- MCTS: /mcts shader preview ------------------------------
//  Rewritten by /mcts shader <effect>; /mcts shader zapisz <slot> copies it
//  into a live slot. Never use #F8F430 in messages.

TEXT_EFFECT_WITH_SHADOW(rgb(0xF8F430)) { // preview
    apply_aurora(vec3(1.0, 0.3, 0.7), vec3(0.3, 1.0, 0.6), vec3(0.4, 0.6, 1.0), 0.42);
}
