// ================================================================
//  Loading screen effect (p == 33)  -  ScreenShaders add-on
// ----------------------------------------------------------------
//  Fullscreen "MCTS"-style loading overlay:
//    - dark backdrop with scattered (off-grid) 5-pointed stars
//      with strongly rounded points (echoing the logo), slowly
//      rotating at mixed speeds and directions, that mathematically
//      can never overlap
//    - HIGH-RES logo: the 508x322 image is served by FOUR font
//      glyphs (font atlas pages are capped at 256x256, so one glyph
//      could only ever hold ~254px), but all four come from a
//      SINGLE texture file (loading_logo.png, 512x326, a 2x2 char
//      grid in the font provider). The tiles carry 1px borders
//      duplicated from their neighbours, and the shader does its
//      own premultiplied bilinear filtering, so seams are invisible
//      and edges are clean: transparent texels also had their RGB
//      flood-filled with the nearest logo colour so filtering never
//      bleeds black. Sampling is a single bilinear tap - the logo is
//      never softened or downscaled.
//    - indeterminate (stateless) looping loading bar with a
//      configurable gold -> orange gradient
//    - the whole overlay enters/leaves through an INVERTED
//      5-pointed star iris (point up): the star is a hole cut
//      out of the overlay
//
//  All edge anti-aliasing (stars, bar, iris) is derived from
//  fwidth(), i.e. exactly ~1 real framebuffer pixel, so the effect
//  is razor sharp at ANY screen resolution instead of having a
//  fixed physical blur.
//
//  The overlay also writes gl_FragDepth = 0.0 (nearest possible),
//  so any depth-tested UI drawn after it (chat, hotbar, ...) fails
//  the depth test and the overlay stays ON TOP.
//
//  TIMING MODEL:
//    - background stars, logo shimmer and the bar sweep run on the
//      continuous GameTime clock (LS_CLOCK), so they animate
//      smoothly forever and NEVER reset or jump when titles change
//      (intro -> outro, re-sent intro, ...).
//    - only the star iris follows the title fade alpha, and it does
//      so across the ENTIRE fade:
//        fade-in  = the entrance animation (iris closes over the
//                   whole fade-in),
//        stay     = how long the screen remains (alpha frozen at 1,
//                   but everything keeps animating on GameTime),
//        fade-out = the exit (iris opens over the whole fade-out,
//                   starting immediately).
//    - the loading bar is intro-only; its track fades in over the
//      last (1 - LS_BAR_APPEAR) of the fade-in, i.e. it appears as
//      the stay begins, then sweeps for the entire stay. A stateless
//      shader cannot know when the stay began (alpha is frozen at 1
//      the whole time), so the sweep phase is the GLOBAL clock -
//      but sending the intro on a gametime multiple of 50t with a
//      fade-in that is a multiple of 50t makes the first sweep
//      begin EXACTLY at the start of the stay (LS_BAR_PERIOD =
//      2.5s = 50t; the sweep starts with the segment fully
//      off-screen left, so it visibly "starts" right then).
//
//  GLYPHS - every marker glyph's corner pixels are RGBA(role,0,0,4):
//    role: 0 = backdrop + stars + bar + iris
//          1..4 = logo tile (TL, TR, BL, BR)
//
//  There is only ONE set of glyphs now: "载甲乙丙丁" (backdrop char
//  FIRST - draw order matters). INTRO vs OUTRO is selected purely by
//  the title COLOR: any color with blue < 254/255 switches to outro.
//  #FFFFFE looks identical to white, so use that.
//
//  COMMANDS (20t = 1s) - see loading_screen_config.glsl for the
//  full, user-facing write-up:
//    intro (fade-in = entrance over the WHOLE fade-in, stay =
//           display time; bar appears at stay start):
//        /title @s times 100t 1200t 0t
//        /title @s title "载甲乙丙丁"
//    outro (NO loading bar; the star iris starts opening IMMEDIATELY
//           and grows over the whole fade-out):
//        /title @s times 0t 0t 100t
//        /title @s title {"text":"载甲乙丙丁","color":"#FFFFFE"}
//
//  LS_BAR_PERIOD and LS_SHIMMER_PERIOD divide the 1200s GameTime
//  wrap evenly, and every background star completes whole
//  fifth-turns (stars are 5-fold symmetric) per LS_TIME_SCALE
//  seconds, so even the GameTime wrap is seamless.
//
//  Trigger: any glyph whose corner pixels have alpha == 4/255.
// ================================================================

#moj_import <minecraft:mcts_loading_screen_config.glsl>

float lsRoundBox(vec2 p, vec2 b, float r)
{
    vec2 q = abs(p) - b + r;
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
}

//Signed distance to an n-pointed star (negative inside).
//In this parametrization one outer vertex lies on the +Y axis,
//so with no extra rotation the star's point faces UP.
float lsStar(vec2 p, float r, float n, float m)
{
    float an = PI / n;
    float en = PI / m;
    vec2 acs = vec2(cos(an), sin(an));
    vec2 ecs = vec2(cos(en), sin(en));

    float bn = mod(atan(p.x, p.y), 2.0 * an) - an;
    p = length(p) * vec2(cos(bn), abs(sin(bn)));

    p -= r * acs;
    p += ecs * clamp(-dot(p, ecs), 0.0, r * acs.y / ecs.y);
    return length(p) * sign(p.x);
}

//Soft mask of a rounded star: 1 inside, 0 outside, px = edge softness
float lsStarMask(vec2 p, float radius, float px)
{
    if (radius <= 0.0)
        return 0.0;

    float d = lsStar(p, radius, LS_STAR_POINTS, LS_STAR_SHAPE) - radius * LS_STAR_ROUND;
    return 1.0 - smoothstep(-px, px, d);
}

//Inverted star iris shared by every glyph of the overlay: 1 where
//the overlay covers the screen, 0 inside the star-shaped hole.
//The hole follows the fade alpha across the ENTIRE fade, eased:
//  fade-in : alpha 0 -> 1, the star closes over the WHOLE fade-in,
//  fade-out: alpha 1 -> 0, the star starts opening IMMEDIATELY and
//            grows over the WHOLE fade-out.
//One symmetric formula covers both directions.
float lsIris(vec2 sd, float fade, float px)
{
    float a = smoothstep(0.0, 1.0, fade);
    float cover = length(0.5 * ScreenSize / ScreenSize.y) * 1.45; //Radius that fully covers the screen
    return 1.0 - lsStarMask(sd, (1.0 - a) * cover, px * LS_AA);
}

float lsRand(vec2 id, float seed)
{
    return float(abs(hash(int(id.x) * 3251 ^ hash(int(id.y) + int(seed)))) % 1024) / 1023.0;
}

//Scattered 5-pointed stars with strongly rounded points (matching
//the logo's star), rotating slowly at mixed speeds and in both
//directions. Placement is one star per hidden cell, but with a
//large random offset and varied size, so it does not read as a
//grid - while size + jitter stay bounded so a star can never
//leave its cell -> stars never overlap.
//pxc = size of one REAL screen pixel in cell units, so the edge
//anti-aliasing is exactly pixel-wide at any resolution.
vec3 lsBgStars(vec3 bg, vec2 p, float strength, float seed, float t, float pxc)
{
    p /= LS_BG_CELL;
    vec2 id = floor(p);
    vec2 f = p - id - 0.5;

    float h = lsRand(id, seed);
    if (h < 0.15) //Some cells stay empty, breaking the pattern up further
        return bg;

    //Large bounded jitter (+-0.17 of a cell) hides the underlying grid
    vec2 jitter = (vec2(lsRand(id, seed + 5.0), lsRand(id, seed + 9.0)) - 0.5) * 0.34;

    //Per-star speed (1..LS_BG_MAX_FT fifth-turns per LS_TIME_SCALE
    //seconds) and direction. Stars are 5-fold symmetric, so whole
    //fifth-turns (72 deg) per LS_TIME_SCALE keep the GameTime wrap
    //(every 1200s) seamless.
    float dir = fract(h * 3.17) > 0.5 ? 1.0 : -1.0;
    float fturns = 1.0 + floor(fract(h * 13.7) * float(LS_BG_MAX_FT));
    float spin = (2.0 * PI / 5.0) * fturns * dir * t / LS_TIME_SCALE;
    vec2 q = mat2_rotate_z(spin + h * 37.0) * (f - jitter);

    //r in [0.12, 0.22]. The rounding term dilates the star by
    //r * LS_BG_ROUND, so its bounding radius is r * (1 + LS_BG_ROUND)
    //<= 0.32; plus the 0.17 jitter that stays under 0.5 -> the
    //rotated, jittered star always stays inside its own cell.
    float r = 0.12 + 0.10 * fract(h * 7.31);
    float d = lsStar(q, r, 5.0, LS_BG_SHAPE) - r * LS_BG_ROUND;
    float m = 1.0 - smoothstep(-pxc * LS_AA, pxc * LS_AA, d);

    return mix(bg, bg * LS_BG_TINT, m * strength);
}

//Indeterminate (stateless) loading bar: a gold-orange segment
//endlessly sweeping across the track. It never "fills up", so the
//animation can run for any duration and always looks mid-loading.
//px = one real screen pixel -> pixel-perfect edges at any resolution.
vec4 lsBar(vec2 p, float px, float t)
{
    vec2 bhalf = LS_BAR_SIZE;
    float r = bhalf.y;
    float e = px * LS_AA;

    float track = 1.0 - smoothstep(-e, e, lsRoundBox(p, bhalf, r));
    if (track <= 0.0)
        return vec4(0);

    float lt = fract(t / LS_BAR_PERIOD);
    lt = lt * lt * (3.0 - 2.0 * lt); //Silky ease in-out per sweep

    float wseg = bhalf.x * LS_BAR_SEGMENT; //Half-width of the moving segment
    //Segment center travels from fully off the left end to fully off the right end
    float cx = mix(-bhalf.x - wseg, bhalf.x + wseg, lt);

    float fill = 1.0 - smoothstep(-e, e, lsRoundBox(p - vec2(cx, 0.0), vec2(wseg, bhalf.y), r));

    vec3 color = mix(LS_BAR_LEFT, LS_BAR_RIGHT, clamp(p.x / (2.0 * bhalf.x) + 0.5, 0.0, 1.0));
    color *= 1.0 + 0.2 * smoothstep(-bhalf.y, bhalf.y, p.y); //Top highlight

    return vec4(mix(LS_BAR_TRACK, color, fill), track);
}

//One inner-content texel of a logo tile. c may reach into the 1px
//border ([-1] / [inner]) which holds duplicates of the neighbouring
//tile / clamped logo edge, so filtering is seamless across tiles.
//The four border CORNER texels carry the glyph marker - never read
//them, fall back to the vertically adjacent border texel instead.
vec4 lsTexel(vec2 stp, ivec2 inner, ivec2 c)
{
    if ((c.x < 0 || c.x >= inner.x) && (c.y < 0 || c.y >= inner.y))
        c.y = clamp(c.y, 0, inner.y - 1);
    return texture(Sampler0, (stp + 1.5 + vec2(c)) / 256.0);
}

//Manual bilinear sample of a tile's inner content, local in [0,1].
//Independent of the font sampler's filter mode -> always smooth.
//Filtering is done in PREMULTIPLIED alpha: straight-alpha filtering
//lets the RGB of transparent texels bleed into the edges, which is
//exactly what made the logo edges look ragged. Premultiplying first
//weights every texel's colour by its coverage, so edges stay clean.
vec4 lsLogoSample(vec2 stp, ivec2 inner, vec2 local)
{
    vec2 pos = local * vec2(inner) - 0.5;
    vec2 fl = floor(pos);
    vec2 f = pos - fl;
    ivec2 b = ivec2(fl);

    vec4 t00 = lsTexel(stp, inner, b);
    vec4 t10 = lsTexel(stp, inner, b + ivec2(1, 0));
    vec4 t01 = lsTexel(stp, inner, b + ivec2(0, 1));
    vec4 t11 = lsTexel(stp, inner, b + ivec2(1, 1));

    t00.rgb *= t00.a; t10.rgb *= t10.a;
    t01.rgb *= t01.a; t11.rgb *= t11.a;

    vec4 c = mix(mix(t00, t10, f.x), mix(t01, t11, f.x), f.y);
    c.rgb /= max(c.a, 1e-5); //Back to straight alpha for blending
    return c;
}

//Continuous animation clock from GameTime, in SECONDS. GameTime is
//global level time, so switching titles (intro -> outro, re-sending
//the intro, ...) never resets or jumps the animation. GameTime wraps
//every 24000 ticks = 1200s; LS_BAR_PERIOD, LS_SHIMMER_PERIOD and the
//stars' whole fifth-turns per LS_TIME_SCALE all divide 1200
//evenly, so even the wrap is seamless.
#define LS_CLOCK (GameTime * 1200.0)

//The backdrop glyph (role 0): dark background with rotating stars,
//vignette, dither and the loading bar - all masked by the star iris.
vec4 loadingScreen(vec4 col, bool outro)
{
    //Stars + bar run on the continuous GameTime clock; only the
    //star iris is driven by the title fade alpha.
    float t = LS_CLOCK;

    //Aspect-correct coords centered on screen, in units of screen height
    vec2 sd = (gl_FragCoord.xy - 0.5 * ScreenSize) / ScreenSize.y;

    //Size of one REAL framebuffer pixel in sd units, straight from the
    //derivatives - correct at any resolution / render-target scale.
    float px = fwidth(sd.y);

    float iris = lsIris(sd, col.a, px);
    if (iris <= 0.0)
        return vec4(0);

    //Backdrop with scattered, slowly rotating rounded stars
    vec3 bg = LS_BACKGROUND;
    bg = lsBgStars(bg, sd, 0.8, LS_BG_SEED, t, px / LS_BG_CELL);
    bg *= 1.0 - 0.3 * dot(sd, sd);                             //Vignette
    bg += (lsRand(floor(gl_FragCoord.xy), 3.0) - 0.5) / 255.0; //Dither against banding

    vec4 color = vec4(bg, 1.0);

    //Loading bar - INTRO only. The track fades in over the last
    //(1 - LS_BAR_APPEAR) of the fade-in, i.e. right as the stay
    //begins, then keeps sweeping on plain GameTime for the whole
    //"stay". The sweep phase is simply the global clock, so it may
    //appear mid-sweep - intentional (the bar is indeterminate).
    if (!outro)
    {
        float appear = smoothstep(LS_BAR_APPEAR, 1.0, col.a);
        if (appear > 0.0)
        {
            vec4 bar = lsBar(sd - LS_BAR_POS, px, t);
            color.rgb = mix(color.rgb, bar.rgb, bar.a * appear);
        }
    }

    color.a = iris;
    return color;
}

//A logo tile glyph (role 1..4 -> tile 0..3 = TL, TR, BL, BR).
//Each glyph draws only its quarter of the logo, sampled from its own
//256-page texture with seamless manual bilinear filtering, plus the
//shimmer sweep computed in FULL-logo uv so it is continuous across
//all four tiles. Masked by the same star iris as the backdrop.
//The tile's quarter of the logo with the shimmer, no iris - shared with
//the slideshow, which fades the logo out on its own schedule.
vec4 lsLogoTileRaw(int tile, vec2 stp, vec2 res, float t)
{
    vec2 sd = (gl_FragCoord.xy - 0.5 * ScreenSize) / ScreenSize.y;

    //Inner content of this tile (minus the 1px border); all four tiles
    //are equal, so the full logo is 2x inner and shares its aspect.
    ivec2 inner = ivec2(res) - 2;
    vec2 size = vec2(LS_LOGO_HEIGHT * float(inner.x) / float(inner.y), LS_LOGO_HEIGHT);

    //Full-logo uv, y pointing DOWN to match texture space
    vec2 p = sd - LS_LOGO_POS;
    vec2 uv = vec2(p.x / size.x + 0.5, 0.5 - p.y / size.y);
    if (clamp(uv, 0.0, 1.0) != uv)
        return vec4(0);

    //Which quarter is this fragment in? Only draw our own (exclusive
    //regions; the duplicated borders keep the seams continuous).
    vec2 g = uv * 2.0;
    ivec2 tij = min(ivec2(g), ivec2(1));
    if (tij.x + tij.y * 2 != tile)
        return vec4(0);

    vec4 tex = lsLogoSample(stp, inner, g - vec2(tij));

    //Shimmer sweep: top-left -> bottom-right, in FULL-logo uv.
    //LS_SHIMMER_OFFSET desynchronizes it from the loading-bar sweep
    //(both run at the same period on the same GameTime clock).
    float band = uv.x - (1.0 - uv.y) * 0.4 + 0.4 - fract((t + LS_SHIMMER_OFFSET) / LS_SHIMMER_PERIOD) * 1.9;
    tex.rgb = mix(tex.rgb, vec3(1.0), (1.0 - smoothstep(0.0, 0.12, abs(band))) * 0.8);

    return tex;
}

vec4 loadingLogoTile(vec4 col, bool outro, int tile, vec2 stp, vec2 res)
{
    //Shimmer runs on the continuous GameTime clock (never resets on
    //title changes); only the iris follows the fade alpha.
    float t = LS_CLOCK;

    vec2 sd = (gl_FragCoord.xy - 0.5 * ScreenSize) / ScreenSize.y;
    float px = fwidth(sd.y);

    float iris = lsIris(sd, col.a, px);
    if (iris <= 0.0)
        return vec4(0);

    vec4 tex = lsLogoTileRaw(tile, stp, res, t);
    tex.a *= iris;
    return tex;
}
