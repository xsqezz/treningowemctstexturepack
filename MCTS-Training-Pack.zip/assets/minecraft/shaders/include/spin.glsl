void processSpinEffect(inout vec4 vertex, float speed, float axis, bool oneShot, float delay) {

    float time = TAU * fract(GameTime * 1200.0 * speed);
    
    float cosA;
    
    if (oneShot) {
        if (time > PI * 2.0) {
            cosA = 1.0;
        } else {
            cosA = cos(time);
        }
    } else {
        float period = PI * 2.0;
        float cycle = mod(time, period + delay);
        if (cycle < period) {
            cosA = cos(cycle);
        } else {
            cosA = 1.0;
        }
    }
    
    spinFlip = (cosA < 0.0) ? 1.0 : 0.0;
    spinScale = abs(cosA);

    int vid = gl_VertexID % 4;
    spinT0 = vec3(0.0);
    spinT1 = vec3(0.0);
    spinT2 = vec3(0.0);
    spinT3 = vec3(0.0);
    if (vid == 0) { spinT0 = vec3(texCoord0, 1.0); }
    if (vid == 1) { spinT2 = vec3(texCoord0, 1.0); }
    if (vid == 2) { spinT1 = vec3(texCoord0, 1.0); }
    if (vid == 3) { spinT3 = vec3(texCoord0, 1.0); }

    gl_Position = ProjMat * ModelViewMat * vertex;
}

void processSpin(inout vec4 vertex, float speed, float axis) {
    processSpinEffect(vertex, speed, axis, false, 0.0);
}

void processOneSpin(inout vec4 vertex, float speed, float axis) {
    processSpinEffect(vertex, speed, axis, true, 0.0);
}

void processSequentialSpin(inout vec4 vertex, float speed, float axis) {

    // GUI: derive charIndex from Position so the per-character spin phase
    // stays stable when batched neighbors (tab list, multi-line chat) shift
    // gl_VertexID. World text keeps the vertex-id index.
    float charIndex = (ProjMat[3][3] != 0.0)
        ? floor(Position.x / 6.0)
        : floor(float(gl_VertexID) / 4.0);
    // 0 = bez obrotu (t > 1 to przerwa miedzy obrotami)
    float t = speed > 0.0 ? mod((charIndex * 0.4 - GameTime * 1200.0 * speed), 5.0) : 2.0;
    
    float cosA;
    if (t > 1.0) {
        cosA = 1.0;
    } else {
        cosA = cos(TAU * t);
    }
    
    spinFlip = (cosA < 0.0) ? 1.0 : 0.0;
    spinScale = abs(cosA);

    int vid = gl_VertexID % 4;
    spinT0 = vec3(0.0);
    spinT1 = vec3(0.0);
    spinT2 = vec3(0.0);
    spinT3 = vec3(0.0);
    if (vid == 0) { spinT0 = vec3(texCoord0, 1.0); }
    if (vid == 1) { spinT2 = vec3(texCoord0, 1.0); }
    if (vid == 2) { spinT1 = vec3(texCoord0, 1.0); }
    if (vid == 3) { spinT3 = vec3(texCoord0, 1.0); }

    gl_Position = ProjMat * ModelViewMat * vertex;
}
