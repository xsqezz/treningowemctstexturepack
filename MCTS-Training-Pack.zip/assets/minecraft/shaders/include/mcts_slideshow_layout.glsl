#moj_import <minecraft:mcts_slideshow_config.glsl>
#moj_import <minecraft:mcts_slideshow_generated.glsl>

#define SS_PHASE_INTRO     0
#define SS_PHASE_ENTER     1
#define SS_PHASE_SWITCH    2
#define SS_PHASE_OUTRO     3
#define SS_PHASE_FROM_LOAD 4
#define SS_PHASE_TO_LOAD   5
#define SS_PHASE_LOGO      6

float ssEase(float t)
{
    t = clamp(t, 0.0, 1.0);
    return t * t * (3.0 - 2.0 * t);
}

float ssBackOut(float t)
{
    t = clamp(t, 0.0, 1.0);
    float u = t - 1.0;
    return 1.0 + (SS_LOGO_OVERSHOOT + 1.0) * u * u * u + SS_LOGO_OVERSHOOT * u * u;
}

int ssPhase(vec4 col)
{
    return int(round(col.g * 255.0));
}

int ssCurrentSlide(vec4 col)
{
    return int(round(col.b * 255.0));
}

int ssPrevSlide(vec4 col)
{
    return int(round(col.r * 255.0));
}

bool ssIsShadow(vec4 col)
{
    return max(col.r, max(col.g, col.b)) < 0.5;
}

bool ssHostedLoadingGlyph(vec4 col)
{
    return round(col.r * 255.0) == 255.0 && round(col.g * 255.0) <= 5.0;
}

float ssOutroProgress(vec4 col)
{
    return clamp((1.0 - col.a) / SS_OUTRO_SPLIT, 0.0, 1.0);
}

float ssIrisProgress(vec4 col)
{
    return clamp((1.0 - col.a - SS_OUTRO_SPLIT) / (1.0 - SS_OUTRO_SPLIT), 0.0, 1.0);
}

bool ssLogoOutro(vec4 col)
{
    return ssPhase(col) == SS_PHASE_TO_LOAD && ssCurrentSlide(col) == SS_LOGO_SLIDE;
}

float ssLogoOutroBackground(vec4 col)
{
    return 1.0 - ssEase(clamp((1.0 - col.a) / SS_LOGO_OUT_BG, 0.0, 1.0));
}

float ssLogoAlpha(vec4 col)
{
    if (ssPhase(col) == SS_PHASE_FROM_LOAD)
        return 1.0 - ssEase(col.a);
    return 0.0;
}

bool ssTileVisible(vec4 mark, vec4 col)
{
    int phase = ssPhase(col);
    int slide = int(mark.g);
    if (phase == SS_PHASE_ENTER || phase == SS_PHASE_OUTRO || phase == SS_PHASE_FROM_LOAD || phase == SS_PHASE_TO_LOAD)
        return slide == ssCurrentSlide(col);
    if (phase == SS_PHASE_SWITCH)
        return true;
    if (phase == SS_PHASE_LOGO)
        return slide == SS_LOGO_SLIDE || slide == ssPrevSlide(col);
    return false;
}

float ssBackgroundAlpha(vec4 col)
{
    int phase = ssPhase(col);
    if (phase == SS_PHASE_INTRO || phase == SS_PHASE_OUTRO)
        return ssEase(col.a) * SS_BG_ALPHA;
    return SS_BG_ALPHA;
}

float ssBezierX(float t)
{
    float u = 1.0 - t;
    return 3.0 * u * u * t * SS_SWITCH_X1 + 3.0 * u * t * t * SS_SWITCH_X2 + t * t * t;
}

float ssBezierY(float t)
{
    float u = 1.0 - t;
    return 3.0 * u * u * t * SS_SWITCH_Y1 + 3.0 * u * t * t * SS_SWITCH_Y2 + t * t * t;
}

float ssSwitchEase(float x)
{
    x = clamp(x, 0.0, 1.0);
    float t = x;
    for (int i = 0; i < 8; i++)
    {
        float u = 1.0 - t;
        float slope = 3.0 * u * u * SS_SWITCH_X1 + 6.0 * u * t * (SS_SWITCH_X2 - SS_SWITCH_X1) + 3.0 * t * t * (1.0 - SS_SWITCH_X2);
        if (slope < 1e-5)
            break;
        t = clamp(t - (ssBezierX(t) - x) / slope, 0.0, 1.0);
    }
    return ssBezierY(t);
}

vec2 ssSlideHalfSize()
{
    return 0.5 * vec2(SS_SLIDE_HEIGHT * SS_SLIDE_ASPECT, SS_SLIDE_HEIGHT);
}

void ssBarRect(out vec2 center, out vec2 halfSize)
{
    vec2 slideHalf = ssSlideHalfSize();
    center = vec2(SS_SLIDE_POS.x, SS_SLIDE_POS.y - slideHalf.y - SS_BAR_OFFSET);
    halfSize = vec2(slideHalf.x * SS_BAR_WIDTH, SS_BAR_HEIGHT) + SS_BAR_MARGIN;
}

float ssBarProgress(vec4 col)
{
    ivec3 c = ivec3(round(col.rgb * 255.0));
    float start = float(((c.r & 0x7F) << 8) | c.g);
    float duration = float(c.b) * 2.0;
    if (duration <= 0.0)
        return 1.0;

    float now = GameTime * 24000.0;
    float elapsed = now - start;
    if (elapsed < -12000.0)
        elapsed += 24000.0;
    return clamp(elapsed / duration, 0.0, 1.0);
}

void ssSlideTransform(vec4 mark, vec4 col, float aspect, out vec2 center, out float scale, out float alpha)
{
    int phase = ssPhase(col);
    int slide = int(mark.g);
    float t = ssEase(col.a);
    vec2 halfSize = ssSlideHalfSize();

    center = SS_SLIDE_POS;
    scale = 1.0;
    alpha = 1.0;

    if (phase == SS_PHASE_ENTER || phase == SS_PHASE_FROM_LOAD)
    {
        alpha = t;
        scale = mix(SS_IN_SCALE, 1.0, t);
    }
    else if (phase == SS_PHASE_OUTRO)
    {
        alpha = t;
        scale = mix(SS_END_SCALE, 1.0, t);
    }
    else if (phase == SS_PHASE_TO_LOAD)
    {
        if (slide == SS_LOGO_SLIDE)
        {
            float u = 1.0 - ssEase(1.0 - col.a);
            alpha = u;
            scale = mix(SS_LOGO_OUT_SCALE, 1.0, u);
        }
        else
        {
            float u = 1.0 - ssEase(ssOutroProgress(col));
            alpha = u;
            scale = mix(SS_END_SCALE, 1.0, u);
        }
    }
    else if (phase == SS_PHASE_SWITCH)
    {
        float s = ssSwitchEase(col.a);
        float margin = SS_GLOW_LINE + SS_GLOW_WIDTH * 6.0;
        if (slide == ssCurrentSlide(col))
        {
            center.x = mix(0.5 * aspect + halfSize.x + margin, SS_SLIDE_POS.x, s);
        }
        else
        {
            scale = mix(1.0, SS_OUT_SCALE, s);
            center.x = mix(SS_SLIDE_POS.x, -(0.5 * aspect + halfSize.x * SS_OUT_SCALE + margin), s);
            alpha = mix(1.0, SS_OUT_ALPHA, s);
        }
    }
    else if (phase == SS_PHASE_LOGO)
    {
        if (slide == SS_LOGO_SLIDE)
        {
            float u = clamp((col.a - SS_LOGO_SPLIT) / (1.0 - SS_LOGO_SPLIT), 0.0, 1.0);
            alpha = ssEase(min(1.0, u * 2.0));
            scale = mix(SS_LOGO_IN_SCALE, 1.0, ssBackOut(u));
        }
        else
        {
            float u = 1.0 - ssEase(clamp(col.a / SS_LOGO_SPLIT, 0.0, 1.0));
            alpha = u;
            scale = mix(SS_END_SCALE, 1.0, u);
        }
    }

    if (slide == SS_LOGO_SLIDE)
        scale *= SS_LOGO_SCALE;
}

void ssTileRect(vec4 mark, vec4 col, float aspect, out vec2 tileCenter, out vec2 tileHalf, out float alpha)
{
    float cols = floor(mark.b / 16.0);
    float rows = mark.b - cols * 16.0;
    float row = floor(mark.r / cols);
    float column = mark.r - row * cols;

    vec2 center;
    float scale;
    ssSlideTransform(mark, col, aspect, center, scale, alpha);

    vec2 halfSize = ssSlideHalfSize() * scale;
    tileHalf = halfSize / vec2(cols, rows);

    vec2 topLeft = center + vec2(-halfSize.x, halfSize.y);
    tileCenter = topLeft + vec2((column + 0.5) * 2.0 * tileHalf.x, -(row + 0.5) * 2.0 * tileHalf.y);
}
