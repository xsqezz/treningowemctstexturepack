// ================================================================
//  MCTS stage light - fragment
// ----------------------------------------------------------------
//  Quad ze znacznikiem (patrz rendertype_item_entity_translucent_cull.vsh)
//  zostal rozciagniety na caly ekran, a jego cztery rogi w przestrzeni
//  kamery przychodza w ray_pos1..4. Z rogow odczytujemy:
//    - srodek quada        -> wylot reflektora,
//    - normalna quada      -> kierunek swiecenia (yaw/pitch displaya),
//    - dluzsza krawedz     -> dlugosc smugi (scale.x displaya),
//    - krotsza krawedz     -> promien u konca smugi (scale.y displaya).
//  Promien z kamery przecina sciety stozek analitycznie, a w srodku
//  sumujemy gestosc mgielki po SL_STEPS probkach.
//
//  gl_FragDepth = wyjscie promienia ze stozka (albo plaszczyzna soczewki dla
//  samej poswiaty). Teren w srodku stozka zaslania wiec smuge, a wszystko
//  przezroczyste przed nia i w niej - szyby, woda, czasteczki, druga smuga -
//  rysuje sie normalnie. Z glebia na wejsciu kazda smuga byla lita sciana,
//  ktora wycinala to, co za nia.
// ================================================================

#moj_import <minecraft:mcts_stage_light_config.glsl>

#ifndef PI
#define PI 3.14159265359
#endif

#define SL_V_APPROX 100000.0

float slHash(vec3 p) {
    p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3));
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

float slNoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(mix(slHash(i), slHash(i + vec3(1, 0, 0)), f.x), mix(slHash(i + vec3(0, 1, 0)), slHash(i + vec3(1, 1, 0)), f.x), f.y),
        mix(mix(slHash(i + vec3(0, 0, 1)), slHash(i + vec3(1, 0, 1)), f.x), mix(slHash(i + vec3(0, 1, 1)), slHash(i + vec3(1, 1, 1)), f.x), f.y),
        f.z);
}

// Tecza: odcien 0..1 -> kolor, lekko rozbielony
vec3 slHue(float h) {
    vec3 c = clamp(abs(fract(h + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
    return mix(vec3(1.0), c, 0.85);
}

// Rog quada zakodowany barycentrycznie (patrz vertex stage bordera)
vec3 slVertex(vec4 v) {
    return round(v.xyz * SL_V_APPROX / v.w) / SL_V_APPROX;
}

void slWriteDepth(vec3 pos) {
    vec4 p = ProjMat * vec4(pos, 1.0);
    gl_FragDepth = p.z / p.w * 0.5 + 0.5;
}

// Przedzial t, w ktorym promien ro + t*rd siedzi w scietym stozku o osi u zaczepionej
// w A: promien r0 przy h = 0 rosnie do R przy h = L. false, gdy promien go mija.
bool slCone(vec3 ro, vec3 rd, vec3 A, vec3 u, float L, float r0, float R, out float t0, out float t1) {
    const float INF = 1e9;
    vec3 co = ro - A;
    float ho = dot(co, u);
    float du = dot(rd, u);

    // plaster miedzy plaszczyznami h = 0 i h = L
    float ts0 = -INF, ts1 = INF;
    if (abs(du) < 1e-6) {
        if (ho < 0.0 || ho > L) return false;
    } else {
        float a = -ho / du;
        float b = (L - ho) / du;
        ts0 = min(a, b);
        ts1 = max(a, b);
    }

    // czesc prostopadla do osi: |co_p + t*rd_p|^2 <= (r0 + s*h(t))^2, kwadratowe w t
    float s = (R - r0) / L;
    vec3 cop = co - ho * u;
    vec3 rdp = rd - du * u;
    float k0 = r0 + s * ho;
    float k1 = s * du;
    float qa = dot(rdp, rdp) - k1 * k1;
    float qb = 2.0 * (dot(cop, rdp) - k0 * k1);
    float qc = dot(cop, cop) - k0 * k0;

    float c0, c1;
    if (abs(qa) < 1e-6) {
        if (abs(qb) < 1e-9) {
            if (qc > 0.0) return false;
            c0 = -INF; c1 = INF;
        } else {
            float t = -qc / qb;
            if (qb > 0.0) { c0 = -INF; c1 = t; } else { c0 = t; c1 = INF; }
        }
    } else {
        float disc = qb * qb - 4.0 * qa * qc;
        if (disc < 0.0) {
            if (qa > 0.0) return false;
            c0 = -INF; c1 = INF;
        } else {
            float sq = sqrt(disc);
            float r1 = (-qb - sq) / (2.0 * qa);
            float r2 = (-qb + sq) / (2.0 * qa);
            float lo = min(r1, r2);
            float hi = max(r1, r2);
            if (qa > 0.0) {
                c0 = lo; c1 = hi;
            } else {
                // wnetrze to (-inf, lo] i [hi, inf) - stozek jest wypukly, wiec w plastrze
                // zostaje najwyzej jeden z tych kawalkow
                float len0 = min(ts1, lo) - ts0;
                float len1 = ts1 - max(ts0, hi);
                if (len0 >= len1) { c0 = -INF; c1 = lo; } else { c0 = hi; c1 = INF; }
            }
        }
    }

    t0 = max(max(ts0, c0), 0.0);
    t1 = min(ts1, c1);
    return t1 > t0;
}

void stageLight() {
    // w GUI (rzut ortogonalny) reflektora nie ma co rysowac
    if (ProjMat[3][0] == -1.0) discard;

    bool even = gl_PrimitiveID % 2 == 0;
    vec3 v0 = slVertex(ray_pos1);
    vec3 v2 = slVertex(ray_pos3);
    vec3 vm = even ? slVertex(ray_pos2) : slVertex(ray_pos4);
    vec3 e1 = vm - v0;
    vec3 e2 = v2 - vm;
    vec3 n = normalize(cross(e1, e2)) * (even ? SL_DIR_SIGN : -SL_DIR_SIGN);
    float a = length(e1);
    float b = length(e2);
    float L = max(a, b);
    float R = min(a, b);
    vec3 ax = e1 / a;
    vec3 ay = e2 / b;
    vec3 C = (v0 + v2) * 0.5;

    int preset = mctsLightInfo.y;
    // sky brightness 15 = reflektor zgaszony (kontroler zapala je dopiero po zmroku)
    if (preset == 15) discard;

    float t = GameTime * 1200.0;
    float phase = float(mctsLightInfo.x) * 2.399963; // zloty kat, zeby fazy sie nie zlewaly
    vec3 color = preset < 13 ? SL_COLORS[preset]
               : preset == 13 ? slHue(t / 12.0 + phase / (2.0 * PI))
               : SL_COLORS[0];

    // ruch glowicy: pan wokol jednej krawedzi quada, tilt wokol drugiej;
    // faza 15 (block brightness) = reflektor wycelowany w scene (prezentacja, podsumowanie): tylko lekkie kolysanie
    // SL_AIM_*, a zeby wycelowane lampy nie szly w takt (wszystkie maja faze 15), faze rozsuwa dlugosc smugi -
    // kazda lampa stoi w innej odleglosci od sceny
    bool aimed = mctsLightInfo.x == 15;
    float swayPhase = aimed ? phase + L * 0.73 : phase;
    float pan = radians(aimed ? SL_AIM_PAN_DEG : SL_PAN_DEG) * sin(t * 2.0 * PI / SL_PAN_PERIOD + swayPhase);
    float tilt = radians(aimed ? SL_AIM_TILT_DEG : SL_TILT_DEG) * sin(t * 2.0 * PI / SL_TILT_PERIOD + swayPhase * 1.7);
    vec3 u = n * cos(pan) * cos(tilt) + ax * sin(pan) * cos(tilt) + ay * sin(tilt);

    float breathe = 1.0 + SL_BREATHE * sin(t * 2.0 * PI / SL_BREATHE_PERIOD + phase * 2.3);

    vec3 rd = normalize(ray_glPos);

    // poswiata soczewki: elipsa rysowana na plaszczyznie wylotu (dysk w punkcie odklejal sie
    // od panelu przy patrzeniu z boku), jasniejsza gdy patrzymy w reflektor, niewidoczna od tylu
    vec3 axLong = a >= b ? ax : ay;
    vec3 axShort = a >= b ? ay : ax;
    float halo = 0.0;
    float th = -1.0;
    float denom = dot(rd, u);
    if (abs(denom) > 1e-4) {
        th = dot(C, u) / denom;
        if (th > 0.0) {
            vec3 q = rd * th - C;
            vec2 e = vec2(dot(q, axLong), dot(q, axShort));
            // poswiata w komorkach - pikselowa jak smuga
            if (SL_VOXEL_HALO > 0.0) e = (floor(e / SL_VOXEL_HALO) + 0.5) * SL_VOXEL_HALO;
            e /= vec2(SL_LENS_W, SL_LENS_H);
            float d2 = dot(e, e);
            // szyba soczewki swieci tez z boku, pelna moca gdy patrzymy w lampe, od tylu wcale
            float facing = clamp(-denom * 1.2 + 0.35, 0.0, 1.0);
            // okno do zera w skonczonym promieniu - ogon gaussa na nieskonczonej plaszczyznie
            // dawal ledwo widoczna plame z twarda krawedzia na progu odrzucania, a jej glebokosc
            // wycinala szyby i wode za nia
            float window = 1.0 - smoothstep(SL_LENS_REACH * 0.5, SL_LENS_REACH, sqrt(d2));
            // jadro soczewki, szeroki blask i poziomy blysk jak w obiektywie
            float flare = exp(-e.y * e.y * 30.0) * exp(-abs(e.x) * 1.1) * SL_FLARE * facing;
            halo = ((exp(-d2 * 3.0) * 1.2 + exp(-d2 * 0.4) * 0.2) * facing + flare) * window * SL_HALO;
        }
    }

    float t0, t1;
    vec3 Cb = C + u * SL_FORWARD;
    bool hit = slCone(vec3(0.0), rd, Cb, u, L, SL_R0, R, t0, t1);
    float acc = 0.0;
    if (hit) {
        float dt = (t1 - t0) / float(SL_STEPS);
        // jitter startu probek (interleaved gradient noise) zamiast pasm
        float tt = t0 + dt * fract(52.9829189 * fract(0.06711056 * gl_FragCoord.x + 0.00583715 * gl_FragCoord.y));
        float flow = t * SL_HAZE_SPEED * SL_HAZE_SCALE;
        for (int i = 0; i < SL_STEPS; i++) {
            vec3 pc = rd * tt - Cb;
            float h = dot(pc, u);
            vec3 q = pc - h * u;
            float r = SL_R0 + (R - SL_R0) * h / L;
            vec3 lp = vec3(dot(q, ax), dot(q, ay), h);
            // woksel: wszystko ponizej liczone w srodku komorki ukladu lampy, wiec smuga ma schodki
            // i plaskie plamy jak pixel art zamiast gladkiego gradientu
            if (SL_VOXEL > 0.0) {
                lp = (floor(lp / SL_VOXEL) + 0.5) * SL_VOXEL;
                r = SL_R0 + (R - SL_R0) * lp.z / L;
            }
            // promienie: szum rozciagniety wzdluz osi, plynie od lampy; klebki: drobniejszy szum 3D
            float streak = slNoise(vec3(lp.xy * SL_HAZE_SCALE, (lp.z - t * SL_HAZE_SPEED) * SL_HAZE_SCALE * SL_HAZE_STRETCH));
            float puff = slNoise(lp * SL_HAZE_SCALE * 1.7 + vec3(t * 0.11, -t * 0.07, -flow * 0.5));
            float haze = mix(1.0, 0.15 + 1.7 * streak * (0.6 + 0.8 * puff), SL_HAZE_AMOUNT);
            float hn = clamp(lp.z / L, 0.0, 1.0);
            float rho = length(lp.xy) / r * (1.0 + SL_EDGE_WOBBLE * (puff - 0.5));
            // plaski srodek, krawedz ostra przy lampie i coraz miekksza dalej, jasny rdzen przy osi
            float edge = mix(SL_EDGE_NEAR, SL_EDGE_FAR, hn);
            float radial = smoothstep(1.0, 1.0 - edge, rho) + exp(-rho * rho * SL_CORE_WIDTH) * SL_CORE;
            float axial = (exp(-hn * SL_AXIAL_FALLOFF) + SL_THROAT * exp(-hn * 12.0)) * smoothstep(0.0, 0.05, hn) * (1.0 - smoothstep(0.7, 1.0, hn));
            acc += radial * axial * haze * dt;
            tt += dt;
        }
    }

    // normalizacja do przejscia w poprzek smugi; wzdluz osi (patrzenie w lampe) kilka razy wiecej
    float intensity = acc / (1.4 * R) * SL_STRENGTH * breathe + halo * breathe;
    float alpha = min(SL_MAX_ALPHA, 1.0 - exp(-intensity * SL_ALPHA_K));

    float depthT = hit ? (halo > 0.01 ? min(t1, th) : t1) : th;
    alpha *= 1.0 - smoothstep(SL_FADE_START, SL_FADE_END, depthT);
    // prog ciagly (zero dokladnie na granicy) zamiast twardego ciecia - inaczej wzdluz progu
    // widac kontur smugi i poswiaty
    alpha = (alpha - SL_MIN_ALPHA) / (1.0 - SL_MIN_ALPHA);
    if (alpha <= 0.0) discard;

    // swiatlo dodaje sie do tla: kolor pastelowy, a geste miejsca (rdzen, patrzenie w lampe,
    // skrzyzowanie smug) przepalaja sie do bieli
    vec3 rgb = mix(mix(color, vec3(1.0), SL_PASTEL), vec3(1.0), clamp(intensity * SL_BURN, 0.0, 0.75));
    fragColor = vec4(rgb, alpha);
    slWriteDepth(rd * depthT);
}
