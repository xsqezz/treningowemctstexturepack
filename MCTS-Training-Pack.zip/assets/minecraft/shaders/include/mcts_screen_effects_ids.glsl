// ================================================================
//  MCTS screen effects - effect ids
// ----------------------------------------------------------------
//  Which full-screen effect a glyph triggers is encoded in the
//  marker texel that the glyph's UV points at:
//
//      alpha 251  ->  effect = blue channel   (effects_marks.png)
//      alpha   5  ->  effect 32               (stain.png)
//      alpha   4  ->  effect 33               (loading_bg / loading_logo)
//      alpha   6  ->  effect 34               (slides_bg / slide_N tiles)
//      alpha   7  ->  effect 35               (slides_bar - slideshow progress bar)
//      alpha   3  ->  animated frame (handled in the fragment stage)
// ================================================================

#define MCTS_EFFECT_VIGNETTE        2
#define MCTS_EFFECT_SPIKES          3
#define MCTS_EFFECT_DIAMOND_GRID    4
#define MCTS_EFFECT_DITHER          5
#define MCTS_EFFECT_RADIAL_FADE     6
#define MCTS_EFFECT_SPINNER         7
#define MCTS_EFFECT_STAIN           32
#define MCTS_EFFECT_LOADING         33
#define MCTS_EFFECT_SLIDESHOW       34
#define MCTS_EFFECT_SLIDESHOW_BAR   35

// Marker alpha of an animated-frame glyph.
#define MCTS_ANIMATED_FRAME_MARK 3.0
