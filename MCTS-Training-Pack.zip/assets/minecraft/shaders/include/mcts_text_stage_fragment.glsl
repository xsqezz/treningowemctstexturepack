// ================================================================
//  MCTS text pipeline - fragment stage
// ----------------------------------------------------------------
//  Counterpart of mcts_text_stage_vertex.glsl. Screen effects get
//  first refusal on the fragment; whatever they do not claim is
//  drawn by TheSalt's Text Effects. Its no-effect path is close to,
//  but not exactly, vanilla: world text gets a ~1% depth bias toward
//  the camera and pure white text skips fog (see README.md).
//
//  Requires, in the host, before this import:
//      uniform sampler2D Sampler0;
//      in vec4 vertexColor; in vec2 texCoord0;
//      in float sphericalVertexDistance; in float cylindricalVertexDistance;
//      out vec4 fragColor;
//      #moj_import <minecraft:fog.glsl>
//      #moj_import <minecraft:dynamictransforms.glsl>
//      #moj_import <minecraft:globals.glsl>
// ================================================================

// --- Text Effects varyings ---------------------------------------
in vec3 spinT0;
in vec3 spinT1;
in vec3 spinT2;
in vec3 spinT3;
in float spinFlip;
in float spinScale;

in float fshEffectID;
in vec4 fshBaseColor;
in vec2 fshCharUV;
in vec4 fshEffectColor;
in vec4 fshExtrudeColor2;
in vec4 fshExtrudeColor3;
in vec4 fshEffectParams;
in vec3 fshGlyphT0;
in vec3 fshGlyphT1;
in vec3 fshGlyphT2;
in vec3 fshGlyphT3;
in float fshDisplayAlpha;

// --- MCTS screen effect varyings ---------------------------------
in vec2 ssP1;
in vec2 ssP2;
in vec2 ssCorner;
flat in int ssVert;
flat in int ssEffect;

flat in int mctsClaimed;

#moj_import <minecraft:text_data.glsl>
#moj_import <minecraft:spin_effect.glsl>
#moj_import <minecraft:outline_effect.glsl>
#moj_import <minecraft:hatch_effect.glsl>
#moj_import <minecraft:neon_effect.glsl>
#moj_import <minecraft:split_effect.glsl>
#moj_import <minecraft:chromatic_effect.glsl>
#moj_import <minecraft:extrude_effect.glsl>
#moj_import <minecraft:noise_effect.glsl>
#moj_import <minecraft:liquid_effect.glsl>
#moj_import <minecraft:water_effect.glsl>
#moj_import <minecraft:shine_effect.glsl>
#moj_import <minecraft:mcts_screen_effects_ids.glsl>
#moj_import <minecraft:mcts_screen_utils.glsl>
#moj_import <minecraft:mcts_loading_screen.glsl>
#moj_import <minecraft:mcts_slideshow.glsl>
#moj_import <minecraft:mcts_screen_effects_fragment.glsl>

// Writes fragColor (or discards). Never call it when mctsClaimed is 1.
void mcts_text_fragment() {
    // ============================================================
    // MCTS screen effects
    // ============================================================
    vec4 screenColor;
    if (mcts_screen_fragment(screenColor)) {
        if (screenColor.a == 0.0) {
            discard;
        }
        fragColor = apply_fog(screenColor, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
        return;
    }

    // ============================================================
    // TheSalt's Text Effects (and the no-effect text path)
    // ============================================================
    vec2 uv = texCoord0;

    applySpinEffect(uv, spinT0, spinT1, spinT2, spinT3, spinScale, spinFlip, texCoord0, Sampler0);

    int effectID = int(fshEffectID + 0.5);

    if (effectID == 1) {
        applyOutlineEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                           fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                           Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 2) {
        applyHatchEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                         fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                         GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 3) {
        applyNeonEffect(uv, fshEffectColor, fshEffectParams,
                        fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                        GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 5) {
        applySplitEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                         fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                         GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 6) {
        applyChromaticEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                             fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                             GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 7) {
        applyExtrudeEffect(uv, fshBaseColor, fshEffectColor, fshExtrudeColor2, fshExtrudeColor3,
                           fshEffectParams,
                           fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                           Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 8) {
        applyNoiseEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                         fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                         GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 9) {
        applyLiquidEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                          fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                          GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 10) {
        applyWaterEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                         fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                         GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 11) {
        applyShineEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                         GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    }

    vec4 color = texture(Sampler0, uv) * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);

    // Upstream Text Effects behaviour: pure white text is left unfogged.
    // This is also what gives the reserved #FBFFFF marker colour its flat,
    // fog-free white.
    if (vertexColor.rgb == vec3(1.0, 1.0, 1.0)) {
        fragColor = color;
    }
}
