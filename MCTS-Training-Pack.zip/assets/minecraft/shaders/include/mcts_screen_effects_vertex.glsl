// ================================================================
//  MCTS screen effects - vertex stage
// ----------------------------------------------------------------
//  Turns specially marked font glyphs into full-screen overlays and
//  implements the reserved marker colours (plain white text, hidden
//  text, CustomNameplates pixel shift, scoreboard number removal).
//
//  Requires, in the including shader, before this import:
//      in vec3 Position; in vec4 Color; in vec2 UV0;
//      uniform sampler2D Sampler0;
//      #moj_import <minecraft:dynamictransforms.glsl>  (ModelViewMat)
//      #moj_import <minecraft:projection.glsl>         (ProjMat)
//      #moj_import <minecraft:globals.glsl>            (ScreenSize)
//      out vec4 vertexColor; out vec2 texCoord0;
//      the ss* varyings declared by the core shader
//
//  and
//      #moj_import <minecraft:mcts_screen_effects_ids.glsl>
//
//  Upstream names, for diffing against the stand-alone pack:
//      ssP1 = p1, ssP2 = p2, ssCorner = coord, ssVert = vert,
//      ssEffect = p
// ================================================================

// --- reserved vertex colours -------------------------------------
#define MCTS_COLOR_PLAIN_WHITE  (vec3(251.0, 255.0, 255.0) / 255.0)
#define MCTS_COLOR_HIDDEN       (vec3( 62.0,  63.0,  63.0) / 255.0)
#define MCTS_COLOR_NAMEPLATE    (vec3(255.0, 254.0, 253.0) / 255.0)
#define MCTS_COLOR_SIDEBAR      (vec3(255.0,  85.0,  85.0) / 255.0)

// --- scoreboard sidebar ------------------------------------------
// The red sidebar score is drawn as its own string; blanking the first
// glyph of it removes the number. Raise to 7 to remove two characters.
#define MCTS_SIDEBAR_LAST_VERTEX 3

void mcts_screen_vertex() {
    // Defaults first: the "hidden" colour returns early, and every
    // varying still has to carry a defined value.
    const vec2[4] corners = vec2[4](vec2(0.0), vec2(0.0, 1.0), vec2(1.0), vec2(1.0, 0.0));

    ssP1 = ssP2 = vec2(0.0);
    ssVert = gl_VertexID % 4;
    ssCorner = corners[ssVert];
    ssEffect = 0;

    vec4 vertex = vec4(mctsBasePosition, 1.0);

    if (Color.xyz == MCTS_COLOR_PLAIN_WHITE) {
        // Pure white, unaffected by the lightmap.
        gl_Position = ProjMat * ModelViewMat * vertex;
        vertexColor = vec4(1.0);
    } else if (Color.xyz == MCTS_COLOR_HIDDEN) {
        // Fully hidden glyph.
        gl_Position = vec4(0.0);
        return;
    } else if (Color.xyz == MCTS_COLOR_NAMEPLATE) {
        // CustomNameplates: shift the glyph by one pixel.
        vertex.xy += 1.0;
        gl_Position = ProjMat * ModelViewMat * vertex;
    }
    // No `else` on purpose: ordinary text keeps the position and colour
    // that the text-effect stage produced. texCoord0 is left alone too -
    // the text-effect stage may have padded it (outline / chromatic /
    // extrude / noise / liquid).

    // The marker is matched on the raw vertex colour (ChatFormatting.RED)
    // AND on the historical lightmap-multiplied value, so neither the
    // lightmap, ColorModulator nor a text effect can break the match.
    bool sidebarRed = Color.rgb == MCTS_COLOR_SIDEBAR
                   || (vertexColor.r == 252.0 / 255.0 && vertexColor.g == 84.0 / 255.0);

    if (Position.z == 0.0 &&                   // gui text has depth 0
        gl_Position.x >= 0.94 && gl_Position.y >= -0.35 &&  // sidebar area
        sidebarRed &&
        gl_VertexID <= MCTS_SIDEBAR_LAST_VERTEX) {
        gl_Position = ProjMat * ModelViewMat * vec4(ScreenSize + 100.0, 0.0, 0.0);
    }

    if (ssVert == 0) ssP1 = UV0 * 256.0;
    if (ssVert == 2) ssP2 = UV0 * 256.0;

    // Marker texel of the glyph decides which full-screen effect runs.
    float alpha = round(texture(Sampler0, UV0).a * 255.0);

    if (alpha == 251.0)
        ssEffect = int(round(texture(Sampler0, UV0).b * 255.0));
    else if (alpha == 5.0)
        ssEffect = MCTS_EFFECT_STAIN;
    else if (alpha == 4.0)
        ssEffect = MCTS_EFFECT_LOADING;
    else if (alpha == 6.0)
        ssEffect = MCTS_EFFECT_SLIDESHOW;
    else if (alpha == 7.0)
        ssEffect = MCTS_EFFECT_SLIDESHOW_BAR;

    if (ssEffect == MCTS_EFFECT_SLIDESHOW_BAR) {
        if (Color.r < 0.5) {
            gl_Position = vec4(0.0);
            return;
        }

        float aspect = ScreenSize.x / ScreenSize.y;
        vec2 barCenter;
        vec2 barHalf;
        ssBarRect(barCenter, barHalf);

        vec2 sd = barCenter + barHalf * (ssCorner * 2.0 - 1.0) * vec2(1.0, -1.0);
        gl_Position.xy = sd / vec2(0.5 * aspect, 0.5);
        gl_Position.zw = vec2(-1.0, 1.0);
        vertexColor = Color;
        return;
    }

    if (ssEffect == MCTS_EFFECT_SLIDESHOW) {
        vec4 mark = round(texture(Sampler0, UV0) * 255.0);

        if (max(Color.r, max(Color.g, Color.b)) < 0.5 || (mark.b != 0.0 && !ssTileVisible(mark, Color))) {
            gl_Position = vec4(0.0);
            return;
        }

        if (mark.b != 0.0) {
            float aspect = ScreenSize.x / ScreenSize.y;
            vec2 tileCenter;
            vec2 tileHalf;
            float tileAlpha;
            ssTileRect(mark, Color, aspect, tileCenter, tileHalf, tileAlpha);

            vec2 sd = tileCenter + tileHalf * (ssCorner * 2.0 - 1.0) * vec2(1.0, -1.0);
            gl_Position.xy = sd / vec2(0.5 * aspect, 0.5);
            gl_Position.zw = vec2(-1.0, 1.0);
            vertexColor = Color;
            return;
        }
    }

    if (ssEffect != 0) {
        // Stretch the glyph across the whole screen, in front of everything.
        texCoord0 = UV0 - ssCorner * 56.0 / 256.0;

        gl_Position.xy = (ssCorner * 2.0 - 1.0) * vec2(1.0, -1.0);
        gl_Position.zw = vec2(-1.0, 1.0);
        vertexColor = Color;
    }
}
