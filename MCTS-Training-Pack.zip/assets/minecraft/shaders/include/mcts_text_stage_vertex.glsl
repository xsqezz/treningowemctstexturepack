// ================================================================
//  MCTS text pipeline - vertex stage
// ----------------------------------------------------------------
//  Everything this pack does to text, in one callable function, for
//  its only host, the BetterHud template betterhud/shaders/text.vsh.
//
//  Requires, in the host, before this import:
//      in vec3 Position; in vec4 Color; in vec2 UV0; in ivec2 UV2;
//      uniform sampler2D Sampler0; uniform sampler2D Sampler2;
//      out vec4 vertexColor; out vec2 texCoord0;
//      #moj_import <minecraft:dynamictransforms.glsl>
//      #moj_import <minecraft:projection.glsl>
//      #moj_import <minecraft:globals.glsl>
//  and the host must have set gl_Position, vertexColor and texCoord0
//  to their base values first.
// ================================================================

// --- Text Effects varyings ---------------------------------------
out vec3 spinT0;
out vec3 spinT1;
out vec3 spinT2;
out vec3 spinT3;
out float spinFlip;
out float spinScale;

out float fshEffectID;
out vec4 fshBaseColor;
out vec2 fshCharUV;
out vec4 fshEffectColor;
out vec4 fshExtrudeColor2;
out vec4 fshExtrudeColor3;
out vec4 fshEffectParams;
out vec3 fshGlyphT0;
out vec3 fshGlyphT1;
out vec3 fshGlyphT2;
out vec3 fshGlyphT3;
out float fshDisplayAlpha;

// --- MCTS screen effect varyings ---------------------------------
out vec2 ssP1;
out vec2 ssP2;
out vec2 ssCorner;
flat out int ssVert;
flat out int ssEffect;

// 1 when the vertex was already claimed by the host (a BetterHud HUD
// element), which makes the fragment stage hand it straight back.
flat out int mctsClaimed;

// The position the effect stages build their vertex from. BetterHud
// hands over its pos, but every vertex it moves is claimed and returns
// before the effect stages, so effect colours never animate BetterHud
// HUD text. For every vertex that reaches them this equals Position
// (unless a BetterHud tag supplier edits pos via
// #GenerateOtherMainMethod, which nothing in MCTS does).
vec3 mctsBasePosition;

#moj_import <minecraft:text_effects_utils.glsl>
#moj_import <minecraft:mcts_screen_effects_ids.glsl>
#moj_import <minecraft:mcts_slideshow_layout.glsl>
#moj_import <minecraft:mcts_screen_effects_vertex.glsl>

void mcts_text_vertex(bool claimed, vec3 basePosition) {
    mctsBasePosition = basePosition;
    mctsClaimed = claimed ? 1 : 0;

    spinT0 = vec3(0.0);
    spinT1 = vec3(0.0);
    spinT2 = vec3(0.0);
    spinT3 = vec3(0.0);
    spinFlip = 0.0;
    spinScale = 1.0;

    fshEffectID = 0.0;
    fshBaseColor = Color;
    fshCharUV = UV0;
    fshEffectColor = vec4(0.0);
    fshExtrudeColor2 = vec4(0.0);
    fshExtrudeColor3 = vec4(0.0);
    fshEffectParams = vec4(0.0);
    fshGlyphT0 = vec3(0.0);
    fshGlyphT1 = vec3(0.0);
    fshGlyphT2 = vec3(0.0);
    fshGlyphT3 = vec3(0.0);
    fshDisplayAlpha = Color.a;

    ssP1 = vec2(0.0);
    ssP2 = vec2(0.0);
    ssCorner = vec2(0.0);
    ssVert = gl_VertexID % 4;
    ssEffect = 0;

    if (claimed) {
        return;
    }

    applyTextEffects(mctsBasePosition);
    mcts_screen_vertex();
}

void mcts_text_vertex() {
    mcts_text_vertex(false, Position);
}
