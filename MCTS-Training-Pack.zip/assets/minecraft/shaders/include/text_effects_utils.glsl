// Text Effects by TheSalt_ - https://github.com/TheSalts/Text_Effects
//
// MIT License
//
// Copyright (c) 2026 TheSalt_
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#moj_import <minecraft:common.glsl>
#moj_import <minecraft:offset.glsl>
#moj_import <minecraft:defaults.glsl>
#moj_import <minecraft:rainbow.glsl>
#moj_import <minecraft:wavy.glsl>
#moj_import <minecraft:bouncy.glsl>
#moj_import <minecraft:blinking.glsl>
#moj_import <minecraft:pulse.glsl>
#moj_import <minecraft:spin.glsl>
#moj_import <minecraft:shake.glsl>
#moj_import <minecraft:fade.glsl>
#moj_import <minecraft:iterating.glsl>
#moj_import <minecraft:glitch.glsl>
#moj_import <minecraft:gradient.glsl>
#moj_import <minecraft:scale.glsl>
#moj_import <minecraft:text_effects_api.glsl>
#moj_import <minecraft:apply_effect.glsl>

// ============================================================
// TEXT EFFECTS - Config-based System
// ============================================================
// Edit _config.glsl to customize color-effect mappings
// ============================================================

// Compare the trigger color (0-255) against a color from rgb()/rgba()/argb().
// vec4 inputs (rgba/argb) ignore alpha.
bool colorMatches(ivec3 c, vec3 target) {
    return c == ivec3(target * 255.0 + 0.5);
}
bool colorMatches(ivec3 c, vec4 target) {
    return colorMatches(c, target.rgb);
}

// Match the main color OR its shadow (~25% of main); flags shadow on a shadow match.
bool checkAndSetShadow(ivec3 c, vec3 target) {
    ivec3 t = ivec3(target * 255.0 + 0.5);
    if (c == t) {
        return true;
    }
    if (c == t / 4) {
        currentIsShadow = true;
        return currentIsShadow;
    }
    return false;
}
bool checkAndSetShadow(ivec3 c, vec4 target) {
    return checkAndSetShadow(c, target.rgb);
}

// TEXT_EFFECT macro: matches a color (exact). Pass rgb()/rgba()/argb(); alpha ignored.
#define TEXT_EFFECT(COLOR) if (colorMatches(c, COLOR))

// TEXT_EFFECT_WITH_SHADOW macro: matches a color AND any colour equal to
// floor(color / 4), i.e. the shadow of every colour in its 4-step bucket.
#define TEXT_EFFECT_WITH_SHADOW(COLOR) if (checkAndSetShadow(c, COLOR))

// basePosition equals Position for every vertex that gets here: inside
// the BetterHud shader template every vertex BetterHud moves is claimed
// and skips Text Effects, so effect colours never animate HUD text.
void applyTextEffects(vec3 basePosition) {
    vec4 vertex = vec4(basePosition, 1.0);
    ivec3 c = ivec3(Color.rgb * 255.0 + 0.5);

    // Initialize global state. currentBaseColor.a defaults to 1.0 (no user
    // override) — the text display's own opacity (Color.a) is applied
    // separately at the very end of the pipeline.
    currentVertex = vertex;
    currentBaseColor = vec4(Color.rgb, 1.0);
    currentIsShadow = false;
    currentApplyToShadow = false;

    // ============================================
    // Config-based color-effect mappings
    // ============================================
    #moj_import <minecraft:_config.glsl>

    // If any effect was applied, execute it
    if (hasAnyEffect()) {
        applyEffect(currentVertex, currentBaseColor, currentIsShadow);
        return;
    }

    // === No effect matched, render normally ===
    applyProjection(vertex);
    // Match the effect path's depth bias so effect-triggered shadows don't
    // z-fight with normally-rendered main text. Skip in GUI (ortho) because
    // 1.21.6+ uses tight z-steps for UI layering — a 0.001 nudge there flips
    // tooltip/autocomplete ordering relative to chat.
    if (ProjMat[3][3] == 0.0) {
        // Constant on purpose: upstream ee2244e is not ported (see apply_effect.glsl Phase 7).
        gl_Position.z -= 0.001;
    }
    applyColorTexture();
    finalize();
}

void applyTextEffects() {
    applyTextEffects(Position);
}
