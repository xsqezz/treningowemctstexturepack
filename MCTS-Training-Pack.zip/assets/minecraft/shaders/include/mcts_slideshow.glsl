#moj_import <minecraft:mcts_slideshow_layout.glsl>

float ssStarMask(vec2 sd, float px)
{
    vec2 shift = fract(SS_CLOCK / SS_BG_PERIOD) * vec2(-SS_BG_CELL.x, 2.0 * SS_BG_CELL.y);
    vec2 p = sd - shift;

    float row = floor(p.y / SS_BG_CELL.y);
    float offset = mod(row, 2.0) * 0.5 * SS_BG_CELL.x;
    float x = p.x - offset;
    float column = floor(x / SS_BG_CELL.x);

    vec2 local = vec2(x - (column + 0.5) * SS_BG_CELL.x, p.y - (row + 0.5) * SS_BG_CELL.y);
    vec2 q = mat2_rotate_z(SS_STAR_ROTATION) * local;

    float d = lsStar(q, SS_STAR_RADIUS, 5.0, SS_STAR_SHAPE) - SS_STAR_RADIUS * SS_STAR_ROUND;
    return 1.0 - smoothstep(-px * SS_AA, px * SS_AA, d);
}

vec3 ssShowBackdrop(vec2 sd, float px)
{
    return mix(SS_BG_COLOR, SS_STAR_COLOR, ssStarMask(sd, px));
}

vec3 ssLoadingBackdrop(vec2 sd, float px, float t)
{
    vec3 bg = LS_BACKGROUND;
    bg = lsBgStars(bg, sd, 0.8, LS_BG_SEED, t, px / LS_BG_CELL);
    bg *= 1.0 - 0.3 * dot(sd, sd);
    bg += (lsRand(floor(gl_FragCoord.xy), 3.0) - 0.5) / 255.0;
    return bg;
}

float ssGlowMask(vec2 sd, vec2 center, vec2 halfSize, float px, float t)
{
    vec2 rel = sd - center;
    float d = lsRoundBox(rel, halfSize, SS_GLOW_RADIUS);
    if (d <= 0.0)
        return 0.0;

    float line = 1.0 - smoothstep(SS_GLOW_LINE - px, SS_GLOW_LINE + px, d);
    float halo = exp(-d / SS_GLOW_WIDTH) * SS_GLOW_STRENGTH;

    float pulse = 1.0 + SS_GLOW_PULSE * sin(2.0 * PI * t / SS_GLOW_PULSE_PERIOD);

    float angle = atan(rel.y, rel.x) / (2.0 * PI);
    float sweepPos = fract(t / SS_GLOW_SWEEP_PERIOD);
    float dist = abs(fract(angle - sweepPos + 0.5) - 0.5);
    float sweep = 1.0 + SS_GLOW_SWEEP * (1.0 - smoothstep(0.0, SS_GLOW_SWEEP_WIDTH, dist));

    return clamp((line + halo) * pulse * sweep, 0.0, 1.0);
}

vec3 ssGlowFor(vec3 shade, vec4 col, int slide, float aspect, vec2 sd, float px, float t)
{
    if (slide == SS_LOGO_SLIDE)
        return shade;

    vec4 mark = vec4(0.0, float(slide), 0.0, 0.0);
    vec2 center;
    float scale;
    float alpha;
    ssSlideTransform(mark, col, aspect, center, scale, alpha);
    if (alpha <= 0.0)
        return shade;

    float g = ssGlowMask(sd, center, ssSlideHalfSize() * scale, px, t) * alpha;
    return mix(shade, SS_GLOW_COLOR, g);
}

vec3 ssWithGlow(vec3 shade, vec4 col, vec2 sd, float px, float t)
{
    int phase = ssPhase(col);
    if (phase == SS_PHASE_INTRO)
        return shade;

    float aspect = ScreenSize.x / ScreenSize.y;
    shade = ssGlowFor(shade, col, ssCurrentSlide(col), aspect, sd, px, t);
    if (phase == SS_PHASE_SWITCH)
        shade = ssGlowFor(shade, col, 0, aspect, sd, px, t);
    if (phase == SS_PHASE_LOGO)
        shade = ssGlowFor(shade, col, ssPrevSlide(col), aspect, sd, px, t);
    return shade;
}

vec3 ssLogoHalo(vec3 shade, vec4 col, float aspect, vec2 sd, float t)
{
    if (ssPhase(col) != SS_PHASE_LOGO && !ssLogoOutro(col))
        return shade;

    vec4 mark = vec4(0.0, float(SS_LOGO_SLIDE), 0.0, 0.0);
    vec2 center;
    float scale;
    float alpha;
    ssSlideTransform(mark, col, aspect, center, scale, alpha);
    if (alpha <= 0.0)
        return shade;

    vec2 rel = (sd - center) / (ssSlideHalfSize() * scale * SS_LOGO_HALO_SIZE);
    float pulse = 1.0 + SS_LOGO_HALO_PULSE * sin(6.2831853 * t / SS_LOGO_HALO_PERIOD);
    float g = exp(-dot(rel, rel) * 3.0) * SS_LOGO_HALO_STRENGTH * pulse * alpha;
    return mix(shade, SS_LOGO_HALO_COLOR, clamp(g, 0.0, 1.0));
}

vec4 ssLogoShine(vec4 tex, vec4 mark, vec4 col, float aspect, vec2 sd, float t)
{
    vec2 center;
    float scale;
    float alpha;
    ssSlideTransform(mark, col, aspect, center, scale, alpha);

    vec2 rel = (sd - center) / (ssSlideHalfSize() * scale);
    float u = rel.x + rel.y * SS_LOGO_SHINE_SLANT;
    float pos = mix(-1.6, 1.6, fract(t / SS_LOGO_SHINE_PERIOD));
    float band = 1.0 - smoothstep(0.0, SS_LOGO_SHINE_WIDTH, abs(u - pos));
    tex.rgb = mix(tex.rgb, vec3(1.0), band * SS_LOGO_SHINE_STRENGTH);
    return tex;
}

vec4 slideshowBackground(vec4 col)
{
    if (ssIsShadow(col))
        return vec4(0.0);

    int phase = ssPhase(col);
    float aspect = ScreenSize.x / ScreenSize.y;
    vec2 sd = (gl_FragCoord.xy - 0.5 * ScreenSize) / ScreenSize.y;
    float px = fwidth(sd.y);
    float t = LS_CLOCK;

    if (phase == SS_PHASE_FROM_LOAD)
    {
        float k = ssEase(col.a);
        vec3 shade = mix(ssLoadingBackdrop(sd, px, t), ssShowBackdrop(sd, px), k);
        vec4 bar = lsBar(sd - LS_BAR_POS, px, t);
        shade = mix(shade, bar.rgb, bar.a * (1.0 - k));
        return vec4(ssWithGlow(shade, col, sd, px, t), SS_BG_ALPHA);
    }

    if (ssLogoOutro(col))
    {
        float alpha = ssLogoOutroBackground(col) * SS_BG_ALPHA;
        if (alpha <= 0.0)
            return vec4(0.0);

        return vec4(ssLogoHalo(ssShowBackdrop(sd, px), col, aspect, sd, t), alpha);
    }

    if (phase == SS_PHASE_TO_LOAD)
    {
        float iris = lsIris(sd, 1.0 - ssIrisProgress(col), px);
        if (iris <= 0.0)
            return vec4(0.0);

        float k = 1.0 - ssEase(ssOutroProgress(col));
        vec3 shade = mix(ssLoadingBackdrop(sd, px, t), ssShowBackdrop(sd, px), k);
        return vec4(ssWithGlow(shade, col, sd, px, t), iris * SS_BG_ALPHA);
    }

    float alpha = ssBackgroundAlpha(col);
    if (alpha <= 0.0)
        return vec4(0.0);

    vec3 shade = ssWithGlow(ssShowBackdrop(sd, px), col, sd, px, t);
    shade = ssLogoHalo(shade, col, aspect, sd, t);
    return vec4(shade, alpha);
}

vec4 slideshowTile(vec4 mark, vec4 col, vec2 stp, vec2 res)
{
    if (ssIsShadow(col) || !ssTileVisible(mark, col))
        return vec4(0.0);

    float aspect = ScreenSize.x / ScreenSize.y;
    vec2 sd = (gl_FragCoord.xy - 0.5 * ScreenSize) / ScreenSize.y;

    vec2 center;
    vec2 halfSize;
    float alpha;
    ssTileRect(mark, col, aspect, center, halfSize, alpha);

    if (alpha <= 0.0)
        return vec4(0.0);

    vec2 local = (sd - center + halfSize) / (2.0 * halfSize);
    local.y = 1.0 - local.y;
    if (clamp(local, 0.0, 1.0) != local)
        return vec4(0.0);

    ivec2 inner = ivec2(res) - 2;
    vec4 tex = lsLogoSample(stp, inner, local);
    if (int(mark.g) == SS_LOGO_SLIDE)
        tex = ssLogoShine(tex, mark, col, aspect, sd, LS_CLOCK);
    tex.a *= alpha;
    return tex;
}

vec4 slideshowBar(vec4 col)
{
    if (col.r < 0.5 || col.a <= 0.0)
        return vec4(0.0);

    vec2 sd = (gl_FragCoord.xy - 0.5 * ScreenSize) / ScreenSize.y;
    float px = fwidth(sd.y);
    float e = px * SS_AA;

    vec2 center;
    vec2 halfSize;
    ssBarRect(center, halfSize);
    vec2 bhalf = halfSize - SS_BAR_MARGIN;
    vec2 p = sd - center;
    float r = bhalf.y;

    float track = 1.0 - smoothstep(-e, e, lsRoundBox(p, bhalf, r));
    if (track <= 0.0)
        return vec4(0.0);

    float progress = ssBarProgress(col);
    float fillRight = -bhalf.x + 2.0 * bhalf.x * progress;
    float fillHalf = max((fillRight + bhalf.x) * 0.5, 0.0);
    vec2 fillCenter = vec2(-bhalf.x + fillHalf, 0.0);
    float fill = progress <= 0.0 ? 0.0 : 1.0 - smoothstep(-e, e, lsRoundBox(p - fillCenter, vec2(max(fillHalf, r), bhalf.y), r));

    vec3 shade = mix(SS_BAR_LEFT, SS_BAR_RIGHT, clamp(p.x / (2.0 * bhalf.x) + 0.5, 0.0, 1.0));
    shade *= 1.0 + 0.2 * smoothstep(-bhalf.y, bhalf.y, p.y);

    vec3 barColor = mix(SS_BAR_TRACK, shade, fill);
    float alpha = mix(SS_BAR_TRACK_ALPHA, 1.0, fill) * track * col.a;
    return vec4(barColor, alpha);
}

vec4 slideshowLogoTile(vec4 col, int tile, vec2 stp, vec2 res)
{
    if (ssIsShadow(col))
        return vec4(0.0);

    float alpha = ssLogoAlpha(col);
    if (alpha <= 0.0)
        return vec4(0.0);

    vec4 tex = lsLogoTileRaw(tile, stp, res, LS_CLOCK);
    tex.a *= alpha;
    return tex;
}
