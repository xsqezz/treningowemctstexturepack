MCTS Training resource pack

Zawiera font mcts:default oraz 8 pikselowych ikon HUD. Plugin automatycznie hostuje ZIP przez HTTP na porcie settings.resource-pack-port (domyślnie 8123) i wysyła paczkę klientom przy wejściu. Sprawdź komunikat pluginu: „Paczka MCTS została poprawnie załadowana”. Jeśli status to FAILED_DOWNLOAD, sprawdź zaporę i ustaw settings.resource-pack-host na adres serwera osiągalny z komputera gracza. Dla hostingu publicznego ustaw settings.resource-pack-url na bezpośredni URL do ZIP-a, najlepiej HTTPS.
